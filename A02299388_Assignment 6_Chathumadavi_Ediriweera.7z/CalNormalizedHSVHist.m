%---Chathumadavi Ediriweera, Assignment 6---%
%---Define Compute Normalized Color Histogram function---%
function hist = CalNormalizedHSVHist (im, hBinNum, sBinNum, vBinNum)
 hsv_image = rgb2hsv(im);
 fH = hsv_image(:,:,1);
 fS = hsv_image(:,:,2);
 fV = hsv_image(:,:,3);

 [r, c, ~] = size(im);
 imSize = r*c;
%  hH = imhist(fH, hBinNum)/imSize;
%  hS = imhist(fS, sBinNum)/imSize;
%  hV = imhist(fV, vBinNum)/imSize;
% 
% hist = zeros(1, hBinNum* sBinNum* vBinNum);
% l=1;
% for i=1:hBinNum
%      for j=1:sBinNum
%           for k=1:vBinNum
%               hist(l)= hH(i)*hS(j)*hV(k);
%               l=l+1;
%           end
%         
%     end
% end

%---interval for H---%
 interval_H= (max(fH(:))-min(fH(:)))/hBinNum;

 for i=1:hBinNum
     H(i)=interval_H*i;     
 end

 
 %---interval for S---%
 interval_S= (max(fS(:))-min(fS(:)))/sBinNum;

 for i=1:sBinNum
     S(i)=interval_S*i;     
 end
 
 
 
 %---interval for V---%
 interval_V= (max(fV(:))-min(fV(:)))/vBinNum;

 for i=1:vBinNum
     V(i)=interval_V*i;     
 end
 
 
 [r,c]=size(fH);
 n= hBinNum*sBinNum*vBinNum;
 hist=zeros(1,n);
 l=1;
 for i=1:hBinNum
     for j=1:sBinNum
         for k=1:vBinNum
             for x=1:r
                 for y=1:c
                     if fH(x,y)<H(i) & fS(x,y)<S(j) & fV(x,y)<V(k)
                         hist(1,l)=hist(1,l)+1;
                         fH(x,y)=10;
                         fS(x,y)=10;
                         fV(x,y)=10;
                     end
                 end
             end
             l=l+1;
         end
     end
 end
 hist=hist/ imSize;

  
end