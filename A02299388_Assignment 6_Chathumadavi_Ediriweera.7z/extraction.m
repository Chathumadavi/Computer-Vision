function [matchingrate]= extraction(im,beta,b)
[CA1,CH1,CV1,CD1]=dwt2(im,'db9');
[CA2,CH2,CV2,CD2]=dwt2(CA1,'db9');
[H2,CH3,CV3,CD3]=dwt2(CA2,'db9');
%---size of LL3 approximation subband---%
[r,c]=size(H2);

%rng(2000); %fix the seed of random number generator
%---define b---%
b_1=zeros(1,r*c);
l=length(b_1);
m=1;
for i=1:r
    for j=1:c
        
            if mod(H2(i, j),beta) > (beta/2)
                b_1(m)=1;
            else
                b_1(m)=0;
            end
            m=m+1;
    end
end

count=0;
for k=1:l
    if b(k)==b_1(k)
        count=count+1;
    end
end
matchingrate=count/numel(b)*100;
% [C,S] = wavedec2(im,3,'db9');
% 
% %---LL3 approximation Subband---%
% H1 = appcoef2(C,S,'db9',3); 
% %---size of LL3 approximation subband---%
% [r,c]=size(H1);
% 
% %rng(2000); %fix the seed of random number generator
% %---define b---%
% b1=zeros(1,r*c);
% l=length(b1);
% 
% for i=1:r
%     for j=1:c
%         for k=1:l
%             if mod(H1(i, j),beta) > (beta/2)
%                 b1(1,k)=1;
%             else
%                 b1(1,k)=0;
%             end
%         end
%     end
% end
% 
% count=0;
% for k=1:l
%     if b(1,k)==b1(1,k)
%         count=count+1;
%     end
% end
% matchingrate=count/numel(b)*100;

end