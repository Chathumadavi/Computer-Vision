function [watermarked, difference,b]= embed(im,beta)

image=double(im);


%---3-level �db2� wavelet decomposition---%
[A1,H1,V1,D1] = dwt2(image,'db9');
[A2,H2,V2,D2] = dwt2(A1,'db9');
[H,H3,V3,D3] = dwt2(A2,'db9');

%---size of H---%
[r,c]=size(H);

rng(2000); %fix the seed of random number generator
%---random sequence of 0 & 1s---%
b=round(rand(1,r*c));
l=length(b);
k=1;

%---embedding watermark value to LL3 subband---%
for i=1:r
    for j=1:c
        
            if (b(k)==1 & (mod(H(i,j),beta)>=(0.25*beta)))
                H(i,j)=H(i,j)-mod(H(i,j),beta)+(0.75*beta);
            elseif (b(k)==1 & (mod(H(i,j),beta)<(0.25*beta)))
                H(i,j)= (H(i,j)-(0.25*beta))-mod((H(i,j)-(0.25*beta)),beta)+(0.75*beta);
            elseif (b(k)==0 & (mod(H(i,j),beta)<=(0.75*beta)))
                H(i,j)= H(i,j)- mod(H(i,j),beta)+(0.25*beta);
            elseif (b(k)==0 & (mod(H(i,j),beta)>(0.75*beta)))
                H(i,j)= (H(i,j)+(0.5*beta))- mod((H(i,j)-(0.5*beta)),beta)+(0.25*beta);
            end
       k=k+1;
    end
end

%---Reconstruction of watermarked image---%
recA2=  idwt2(H,H3,V3,D3,'db9');
recA1=  idwt2(recA2,H2,V2,D2,'db9');
watermarked = idwt2(recA1,H1,V1,D1,'db9');




%---Difference at beta---%
difference = image-watermarked;



end