%---Chathumadavi Ediriweera, Assignment 6---%

%---Load the image---%
Ball= imread('Ball.bmp');


%---convert to the HSV color space---%

hsv_image = rgb2hsv(Ball);
%---extracting H space---%
fH = hsv_image(:,:,1);

%---find locations with minimum values---%
loc0 = find(fH<0.09);
B=zeros(size(fH));
%---thresholding---%
B(loc0)=1;
B= imbinarize(B);


%---define structuring element---%
se= strel('disk',3);

closeB=imclose(B,se);


erodeB=imerode(closeB,se);


erodeB2=imerode(erodeB,se);


erodeB3=imerode(erodeB2,se);

%---fill the holes---%
fillB= imfill(erodeB3,'holes');


dilB= imdilate(fillB,se);

figure
subplot(2,4,1)
imshow(fH), title('Ball in H space')
subplot(2,4,2)
imshow(B), title('threshold&binarize')
subplot(2,4,3)
imshow(closeB);title('close operation')
subplot(2,4,4)
imshow(erodeB);title('erosion1 on close operation')
subplot(2,4,5)
imshow(erodeB2);title('erosion2 on close operation')
subplot(2,4,6)
imshow(erodeB3);title('erosion3 on close operation')
subplot(2,4,7)
imshow(fillB);title('fill holes')
subplot(2,4,8)
imshow(dilB);title('dilation operation')
pause;

Ilabel = bwlabel(fillB);
stat = regionprops(Ilabel,'centroid');
figure
imshow(Ball); title('Centroid of the Ball')
hold on;
xCentroid = stat.Centroid(1); 
yCentroid = stat.Centroid(2); 
% Put a cross on it. 
plot(xCentroid, yCentroid, 'r+', 'MarkerSize', 20);
pause;
%---Finished Solving ProblemI.1---%

%---extracting V space---%
fV = hsv_image(:,:,3);
gdil=imdilate(fV,se);
comp_gdil=imcomplement(gdil);

%---Thresholding---%
loc2=find(comp_gdil>=0.6 & comp_gdil<= 0.7);
C=zeros(size(fV));
C(loc2)=1;

C1=imclearborder(C);

fillC=imfill(C1);

%---Finding the largest component---%
Con_Comp = bwconncomp(fillC);
label=labelmatrix(Con_Comp);
measurements = regionprops(label, 'Area');
allAreas = [measurements.Area]; 
max_area= max(allAreas);
l=length(allAreas);
for i=1:l
    if allAreas(i)==max_area
        lab=i;
        break;
    end
end
D= zeros(size(fV));
[r,c]=size(fV);

for i=1:r
    for j=1:c
            if label(i,j)== lab
                 D(i,j)=1; 
            end
       
    end
end
figure;
subplot(2,3,1);
imshow(fV);title('V space')
subplot(2,3,2);
imshow(C); title('After thresholding')
subplot(2,3,3);
imshow(C1);title('Clear border')
subplot(2,3,4);
imshow(fillC);title('Fill holes')
subplot(2,3,5)
imshow(D); title('Shadow')
pause;

D1=imoverlay(Ball,D);
figure
imshow(D1)
pause;
%---Finished Solving ProblemI.2---%

%---Compute Normalized Color Histogram---%
hBinNum= 4;
sBinNum= 4;
vBinNum= 4;
H1 = imread('Horse1.jpg');
hist_H1 = CalNormalizedHSVHist (H1, hBinNum, sBinNum, vBinNum); %Compute Normalized Color Histogram horse1
H2 = imread('Horse2.jpg');
hist_H2 = CalNormalizedHSVHist (H2, hBinNum, sBinNum, vBinNum); %Compute Normalized Color Histogram horse2
E1 = imread('Elephant1.jpg');
hist_E1 = CalNormalizedHSVHist (E1, hBinNum, sBinNum, vBinNum); %Compute Normalized Color Histogram elephant1
E2 = imread('Elephant2.jpg');
hist_E2 = CalNormalizedHSVHist (E2, hBinNum, sBinNum, vBinNum); %Compute Normalized Color Histogram elephant2

figure
subplot(2,2,1)
bar(hist_H1);
title('Normalized Color Histogram: Horse1')
subplot(2,2,2)
bar(hist_H2);
title('Normalized Color Histogram: Horse2')
subplot(2,2,3)
bar(hist_E1);
title('Normalized Color Histogram: Elephant1')
subplot(2,2,4)
bar(hist_E2);
title('Normalized Color Histogram: Elephant2')
pause;

dH1H1 = minhist(H1,H1,hist_H1,hist_H1);
dH1H2 = minhist(H1,H2,hist_H1,hist_H2);
dH1E1 = minhist(H1,E1,hist_H1,hist_E1);
dH1E2 = minhist(H1,E2,hist_H1,hist_E2);
dH2H2 = minhist(H1,H2,hist_H2,hist_H2);
dH2E1 = minhist(H1,E1,hist_H2,hist_E1);
dH2E2 = minhist(H1,E2,hist_H2,hist_E2);
dE1E1 = minhist(E1,E1,hist_E1,hist_E1);
dE1E2 = minhist(E1,E2,hist_E1,hist_E2);
dE2E2 = minhist(E2,E2,hist_E2,hist_E2);
dH1= [dH1H1,dH1H2,dH1E1,dH1E2];
[sd] = sort(dH1,'descend');


l=length(sd);

for i=1:l
    my_field = strcat('rank',num2str(i));
    if sd(i)==dH1H1
       variable.(my_field)=H1;
    elseif sd(i)== dH1H2
        variable.(my_field)=H2;
    elseif sd(i)== dH1E1
            variable.(my_field)=E1;
    elseif sd(i)== dH1E2
        variable.(my_field)=E2;
    end
end

figure
subplot(2,2,1)
imshow(variable.rank1);title(['Rank 1 ,Similarity Score:' num2str(sd(1))])
subplot(2,2,2)
imshow(variable.rank2);title(['Rank 2 ,Similarity Score:' num2str(sd(2))])
subplot(2,2,3)
imshow(variable.rank3);title(['Rank 3 ,Similarity Score:' num2str(sd(3))])
subplot(2,2,4)
imshow(variable.rank4);title(['Rank 4 ,Similarity Score:' num2str(sd(4))])
pause;

dH2= [dH2H2,dH1H2,dH2E1,dH2E2];
[sd2] = sort(dH2,'descend');

l=length(sd2);
for i=1:l
    my_field = strcat('rank',num2str(i));
    if sd2(i)==dH2H2
       variable2.(my_field)=H2;
    elseif sd2(i)== dH1H2
        variable2.(my_field)=H1;
    elseif sd2(i)== dH2E1
            variable2.(my_field)=E1;
    elseif sd2(i)== dH2E2
        variable2.(my_field)=E2;
    end
end

figure
subplot(2,2,1)
imshow(variable2.rank1);title(['Rank 1 ,Similarity Score:' num2str(sd2(1))])
subplot(2,2,2)
imshow(variable2.rank2);title(['Rank 2 ,Similarity Score:' num2str(sd2(2))])
subplot(2,2,3)
imshow(variable2.rank3);title(['Rank 3 ,Similarity Score:' num2str(sd2(3))])
subplot(2,2,4)
imshow(variable2.rank4);title(['Rank 4 ,Similarity Score:' num2str(sd2(4))])
pause;



dE1= [dE1E1,dH1E1,dH2E1,dE1E2];
[sd3] = sort(dE1,'descend');
l=length(sd3);
for i=1:l
    my_field = strcat('rank',num2str(i));
    if sd3(i)==dE1E1
       variable3.(my_field)=E1;
    elseif sd3(i)== dH1E1
        variable3.(my_field)=H1;
    elseif sd3(i)== dH2E1
            variable3.(my_field)=H2;
    elseif sd3(i)== dE1E2
        variable3.(my_field)=E2;
    end
end

figure
subplot(2,2,1)
imshow(variable3.rank1);title(['Rank 1 ,Similarity Score:' num2str(sd3(1))])
subplot(2,2,2)
imshow(variable3.rank2);title(['Rank 2 ,Similarity Score:' num2str(sd3(2))])
subplot(2,2,3)
imshow(variable3.rank3);title(['Rank 3 ,Similarity Score:' num2str(sd3(3))])
subplot(2,2,4)
imshow(variable3.rank4);title(['Rank 4 ,Similarity Score:' num2str(sd3(4))])
pause;

dE2= [dE2E2,dH1E2,dH2E2,dE1E2];
[sd4] = sort(dE2,'descend');
l=length(sd4);
for i=1:l
    my_field = strcat('rank',num2str(i));
    
    if sd4(i)==dE2E2
        variable4.(my_field)=E2;
    elseif sd4(i)== dH1E2
        variable4.(my_field)=H1;
    elseif sd4(i)== dH2E2
        variable4.(my_field)=H2;
    elseif sd4(i)== dE1E2
        variable4.(my_field)=E1;
    end
end
figure
subplot(2,2,1)
imshow(variable4.rank1);title(['Rank 1 ,Similarity Score:' num2str(sd4(1))])
subplot(2,2,2)
imshow(variable4.rank2);title(['Rank 2 ,Similarity Score:' num2str(sd4(2))])
subplot(2,2,3)
imshow(variable4.rank3);title(['Rank 3 ,Similarity Score:' num2str(sd4(3))])
subplot(2,2,4)
imshow(variable4.rank4);title(['Rank 4 ,Similarity Score:' num2str(sd4(4))])
%---Finish Solving Problem II---%
pause;

%---Problem 3: A Simple Watermarking Technique in Wavelet Domain---%
%---Load the image---%
Lena= imread('Lena.jpg');
dwtmode('per')
%---Calling embed function---%
[watermarked, difference,b]= embed(Lena,30);
%---Scaling images---%
scaled_watermarked = uint8(Scaling(watermarked,[0,255]));
difference= uint8(Scaling(difference,[0,255]));

%---Display images---%
figure
subplot(1,3,1)
imshow(Lena);title('Original')
subplot(1,3,2)
imshow(scaled_watermarked);title('watermarked,beta=30')
subplot(1,3,3)
imshow(difference);title('difference,beta=30')
pause;

%---Calling embed function---%
[watermarked2, difference2,b]= embed(Lena,90);
%---Scaling images---%
scaled_watermarked2 = uint8(Scaling(watermarked2,[0,255]));
difference2= uint8(Scaling(difference2,[0,255]));

%---Display images, beta=90---%
figure
subplot(1,3,1)
imshow(Lena);title('Original')
subplot(1,3,2)
imshow(scaled_watermarked2);title('watermarked, beta=90')
subplot(1,3,3)
imshow(difference2);title('difference,beta=90')
pause;
%---Finish Solving ProblemIII.1---%

%---Calling extraction function---%
[matchingrate]= extraction(watermarked,30,b);
disp("Matching percentage for watermark image at beta=30:")
disp(matchingrate);

%---Calling extraction function---%
[matchingrate2]= extraction(watermarked2,90,b);
disp("Matching percentage for watermark image at beta=90:")
disp(matchingrate2);
pause;
%---Finish Solving ProblemIII.2---%

clear;
close all;

