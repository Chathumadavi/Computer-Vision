function score = minhist(im1,im2,hist1,hist2)
n=length(hist1);

%---Size of im1---%
[r1,c1]=size(im1);
p1= r1*c1; %no. of pixels:im1

%---Size of im2---%
[r2,c2]=size(im2);
p2= r2*c2; %no. of pixels:im2

%---multiply by number of pixels---%
im1_p= hist1*p1;
im2_p= hist2*p2;

for i=1:n
    min_im1_im2(i)= min(im1_p(i),im2_p(i));
        
end
 
score= sum(min_im1_im2)/(min(p1,p2));


end