%---Loading ZIKV Infected Plate 1 images---%
Z_P1_1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
%---Converting into grayscale---%
g_Z_P1_1=rgb2gray(Z_P1_1);
%---Increase contrast of image---%
c_Z_P1_1=imadjust(g_Z_P1_1);
figure;
subplot(1,2,1)
imshow(Z_P1_1)
title('Zika Plate 1 A1 Bright')
subplot(1,2,2)
imshow(c_Z_P1_1)
title('Contrast Zika Plate 1 A1 Bright')
pause;

Z_P1_5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
%---Converting into grayscale---%
g_Z_P1_5=rgb2gray(Z_P1_5);
%---Increase contrast of image---%
c_Z_P1_5=imadjust(g_Z_P1_5);
figure;
subplot(1,2,1)
imshow(Z_P1_5)
title('Zika Plate 1 A5 Bright')
subplot(1,2,2)
imshow(c_Z_P1_5)
title('Contrast Zika Plate 1 A5 Bright')
pause;

%---Loading Non-Infected Plate 1 images---%
N_P1_2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
%---Converting into grayscale---%
g_N_P1_2=rgb2gray(N_P1_2);
%---Increase contrast of image---%
c_N_P1_2=imadjust(g_N_P1_2);
figure;
subplot(1,2,1)
imshow(N_P1_2)
title('Control Plate 1 A2 Bright')
subplot(1,2,2)
imshow(c_N_P1_2)
title('Contrast Control Plate 1 A2 Bright')
pause;

N_P1_4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
%---Converting into grayscale---%
g_N_P1_4=rgb2gray(N_P1_4);
%---Increase contrast of image---%
c_N_P1_4=imadjust(g_N_P1_4);
figure;
subplot(1,2,1)
imshow(N_P1_4)
title('Control Plate 1 A4 Bright')
subplot(1,2,2)
imshow(c_N_P1_4)
title('Contrast Control Plate 1 A4 Bright')

pause;
close all;
clear all;