%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P2_A2 = imread('./ZIKV Infected/Plate 2_A2 Bright.jpg');
Z_P2_A2= imresize(imcrop(Z_P2_A2,[800 600 500 650]),[500 500]);
Z_P2_A2_lab = rgb2lab(Z_P2_A2);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P2_A2_lab(:,:,1)/max_luminosity;

 %---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%


Z_P2_A2_histeq = Z_P2_A2_lab;
Z_P2_A2_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P2_A2_histeq = lab2rgb(Z_P2_A2_histeq);

Z_P2_A2_min = min(Z_P2_A2_histeq(:))
Z_P2_A2_max = max(Z_P2_A2_histeq(:))
Z_P2_A2_mean = mean(Z_P2_A2_histeq(:))
Z_P2_A2_std = std(Z_P2_A2_histeq(:))

figure,imshow(Z_P2_A2_histeq)
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P2_A4 = imread('./ZIKV Infected/Plate 2_A4 Bright.jpg');
Z_P2_A4= imresize(imcrop(Z_P2_A4,[900 700 450 450]),[500 500]);
Z_P2_A4_lab = rgb2lab(Z_P2_A4);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P2_A4_lab(:,:,1)/max_luminosity;

 %---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%


Z_P2_A4_histeq = Z_P2_A4_lab;
Z_P2_A4_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P2_A4_histeq = lab2rgb(Z_P2_A4_histeq);

Z_P2_A4_min = min(Z_P2_A4_histeq(:))
Z_P2_A4_max = max(Z_P2_A4_histeq(:))
Z_P2_A4_mean = mean(Z_P2_A4_histeq(:))
Z_P2_A4_std = std(Z_P2_A4_histeq(:))

figure,imshow(Z_P2_A4_histeq)
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A1 = imread('./Non-Infected Controls/Plate 2_A1 Bright.jpg');
N_P2_A1= imresize(imcrop(N_P2_A1,[650 500 550 450]),[500 500]);
N_P2_A1_lab = rgb2lab(N_P2_A1);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A1_lab(:,:,1)/max_luminosity;

 %---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%


N_P2_A1_histeq = N_P2_A1_lab;
N_P2_A1_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A1_histeq = lab2rgb(N_P2_A1_histeq);

N_P2_A1_min = min(N_P2_A1_histeq(:))
N_P2_A1_max = max(N_P2_A1_histeq(:))
N_P2_A1_mean = mean(N_P2_A1_histeq(:))
N_P2_A1_std = std(N_P2_A1_histeq(:))

figure,imshow(N_P2_A1_histeq)
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A3 = imread('./Non-Infected Controls/Plate 2_A3 Bright.jpg');
N_P2_A3= imresize(imcrop(N_P2_A3,[670 800 400 380]),[500 500]);
N_P2_A3_lab = rgb2lab(N_P2_A3);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A3_lab(:,:,1)/max_luminosity;

 %---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%


N_P2_A3_histeq = N_P2_A3_lab;
N_P2_A3_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A3_histeq = lab2rgb(N_P2_A3_histeq);

N_P2_A3_min = min(N_P2_A3_histeq(:))
N_P2_A3_max = max(N_P2_A3_histeq(:))
N_P2_A3_mean = mean(N_P2_A3_histeq(:))
N_P2_A3_std = std(N_P2_A3_histeq(:))

figure,imshow(N_P2_A3_histeq)

%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A5 = imread('./Non-Infected Controls/Plate 2_A5 Bright.jpg');
N_P2_A5= imresize(imcrop(N_P2_A5,[808 685 384 402]),[500 500]);
N_P2_A5_lab = rgb2lab(N_P2_A5);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A5_lab(:,:,1)/max_luminosity;

 %---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%


N_P2_A5_histeq = N_P2_A5_lab;
N_P2_A5_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A5_histeq = lab2rgb(N_P2_A5_histeq);

N_P2_A5_min = min(N_P2_A5_histeq(:))
N_P2_A5_max = max(N_P2_A5_histeq(:))
N_P2_A5_mean = mean(N_P2_A5_histeq(:))
N_P2_A5_std = std(N_P2_A5_histeq(:))

figure,imshow(N_P2_A5_histeq)
