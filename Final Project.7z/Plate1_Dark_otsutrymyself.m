close all;
Z_P1_1=imread('./ZIKV Infected/Plate 1_A1 Dark.jpg');
I= imcomplement(rgb2gray(Z_P1_1));

[I2,I3,bw,cc1,cell1,celldata1,RGB_labeled]= otsumyfunction(I,1);

montage({Z_P1_1,I,I2,I3,cell1,RGB_labeled},'Size',[1 6])
title("Zika Plate 1 A1 Dark,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
pause;
%----------------------------------------------------------------------
Z_P1_5=imread('./ZIKV Infected/Plate 1_A5 Dark.jpg');
I= imcomplement(rgb2gray(Z_P1_5));

[I2,I3,bw,cc1,cell5,celldata5,RGB_labeled]= otsumyfunction(I,1);

montage({Z_P1_5,I,I2,I3,cell5,RGB_labeled},'Size',[1 6])
title("Zika Plate 1 A5 Dark,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
pause;
%--------------------------------------------------------------------------
N_P1_2=imread('./Non-Infected Controls/Plate 1_A2 Dark.jpg');
I= imcomplement(rgb2gray(N_P1_2));

 [I2,I3,bw,cc1,cell2,celldata2,RGB_labeled]= otsumyfunction(I,1);


montage({N_P1_2,I,I2,I3,cell2,RGB_labeled},'Size',[1 6])
title("Control Plate 1 A2 Dark,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
pause;

% %--------------------------------------------------------------------------
N_P1_4=imread('./Non-Infected Controls/Plate 1_A4 Dark.jpg');
I= imcomplement(rgb2gray(N_P1_4));

[I2,I3,bw,cc1,cell4,celldata4,RGB_labeled]= otsumyfunction(I,1);


montage({N_P1_4,I,I2,I3,cell4,RGB_labeled},'Size',[1 6])
title("Control Plate 1 A4 Dark,Complement, Enhanced Image,Imadjust image, Object,RGB Image")


