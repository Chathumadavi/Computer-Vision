function [I2,I3,bw,cc1,cell,celldata,RGB_labeled]= otsumyfunction(I,i)

background = imopen(I,strel('disk',500));
figure,imshow(background);

I2= I-background;

I3= imadjust(I2);


bw=imbinarize(I3);
%---Creating structuring element---%
b= strel('square',25);

%---Dilation---%
bw= imopen(imerode(bw,b),b);

 bw=bwareaopen(bw,1000);


cc=bwconncomp(bw,4);
cc1=bwconncomp(bw);

cell= false(size(bw));
cell(cc1.PixelIdxList{i})= true;


labeled = labelmatrix(cc1);
RGB_labeled = label2rgb(labeled, @spring, 'c', 'shuffle');
celldata = regionprops(cc1,'basic');
end