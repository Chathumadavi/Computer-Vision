%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P1_A1 = imread('./ZIKV Infected/Plate 1_A1 Dark.jpg');
Z_P1_A1_lab = rgb2lab(Z_P1_A1);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P1_A1_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P1_A1_imadjust = Z_P1_A1_lab;
Z_P1_A1_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P1_A1_imadjust = lab2rgb(Z_P1_A1_imadjust);

Z_P1_A1_histeq = Z_P1_A1_lab;
Z_P1_A1_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P1_A1_histeq = lab2rgb(Z_P1_A1_histeq);

Z_P1_A1_adapthisteq = Z_P1_A1_lab;
Z_P1_A1_adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
Z_P1_A1_adapthisteq = lab2rgb(Z_P1_A1_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({Z_P1_A1,Z_P1_A1_imadjust,Z_P1_A1_histeq,Z_P1_A1_adapthisteq},'Size',[1 4])
title("Original Image and Enhanced Images using imadjust, histeq, and adapthisteq")
%------------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P1_A5 = imread('./ZIKV Infected/Plate 1_A5 Dark.jpg');
Z_P1_A5_lab = rgb2lab(Z_P1_A5);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P1_A5_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P1_A5_imadjust = Z_P1_A5_lab;
Z_P1_A5_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P1_A5_imadjust = lab2rgb(Z_P1_A5_imadjust);

Z_P1_A5_histeq = Z_P1_A5_lab;
Z_P1_A5_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P1_A5_histeq = lab2rgb(Z_P1_A5_histeq);

Z_P1_A5_adapthisteq = Z_P1_A5_lab;
Z_P1_A5_adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
Z_P1_A5_adapthisteq = lab2rgb(Z_P1_A5_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({Z_P1_A5,Z_P1_A5_imadjust,Z_P1_A5_histeq,Z_P1_A5_adapthisteq},'Size',[1 4])
title("Original Image Z_P1_A5 and Enhanced Images using imadjust, histeq, and adapthisteq")

%---------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P1_A2 = imread('./Non-Infected Controls/Plate 1_A2 Dark.jpg');
N_P1_A2_lab = rgb2lab(N_P1_A2);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P1_A2_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P1_A2_imadjust = N_P1_A2_lab;
N_P1_A2_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P1_A2_imadjust = lab2rgb(N_P1_A2_imadjust);

N_P1_A2_histeq = N_P1_A2_lab;
N_P1_A2_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P1_A2__histeq = lab2rgb(N_P1_A2_histeq);

N_P1_A2_adapthisteq = N_P1_A2_lab;
N_P1_A2__adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
N_P1_A2_adapthisteq = lab2rgb(N_P1_A2_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({N_P1_A2,N_P1_A2_imadjust,N_P1_A2_histeq,N_P1_A2_adapthisteq},'Size',[1 4])
title("Original Image N_P1_A2 and Enhanced Images using imadjust, histeq, and adapthisteq")

%--------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P1_A4 = imread('./Non-Infected Controls/Plate 1_A4 Dark.jpg');
N_P1_A4_lab = rgb2lab(N_P1_A4);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P1_A4_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P1_A4_imadjust = N_P1_A4_lab;
N_P1_A4_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P1_A4_imadjust = lab2rgb(N_P1_A4_imadjust);

N_P1_A4_histeq = N_P1_A4_lab;
N_P1_A4_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P1_A4__histeq = lab2rgb(N_P1_A4_histeq);

N_P1_A4_adapthisteq = N_P1_A4_lab;
N_P1_A4__adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
N_P1_A4_adapthisteq = lab2rgb(N_P1_A4_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({N_P1_A4,N_P1_A4_imadjust,N_P1_A4_histeq,N_P1_A4_adapthisteq},'Size',[1 4])
title("Original Image N_P1_A4 and Enhanced Images using imadjust, histeq, and adapthisteq")