close all;
Z_P1_1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
Z_P1_1= rgb2gray(Z_P1_1);
%mask = ones([3 3]);
%[Z_P1_1] = MedianFiltering(Z_P1_1,mask);
I1=blkproc(Z_P1_1,[375 375], @adaptt);
figure
imshow(I1)


 Z_P1_5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
 Z_P1_5= rgb2gray(Z_P1_5);
 %[Z_P1_5] = MedianFiltering(Z_P1_5,mask);
 I2=blkproc(Z_P1_5,[375 375], @adaptt);
 figure
imshow(I2)

 N_P1_2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
 N_P1_2= rgb2gray(N_P1_2);
%[N_P1_2] = MedianFiltering(N_P1_2,mask);
 I3=blkproc(N_P1_2,[375 375], @adaptt);
 figure
 imshow(I3)

 
 N_P1_4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
 N_P1_4= rgb2gray(N_P1_4);
 %[N_P1_4] = MedianFiltering(N_P1_4,mask);
 I4=blkproc(N_P1_4,[375 375], @adaptt);
 figure
 imshow(I4)
 
% figure
% montage({Z_P1_1,Z_P1_5,N_P1_2,N_P1_4,I1,I2,I3,I4},'Size',[2 4])
% title("Zika Plate 1 A1,Zika Plate 1 A5,Control Plate 1 A2,Control Plate 1 A4,Adaptive Threshold: A1, A5,A2, A4")
% pause;

