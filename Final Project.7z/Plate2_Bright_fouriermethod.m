%Fourier Transformation%
%---Read an image into the workspace. convert the image from the RGB color space to grayscale.%
N_P2_A1 = imread('./Non-Infected Controls/Plate 2_A1 Bright.jpg');
N_P2_A1= imresize(imcrop(N_P2_A1,[650 500 550 450]),[500 500]);
%--median filer--%
A1=medfilt2(rgb2gray(N_P2_A1));
figure
subplot(1,2,1)
imshow(N_P2_A1),title('Control Plate2 A1')
subplot(1,2,2)
imshow(A1),title('median filtered Control Plate2 A1')

N_P2_A3 = imread('./Non-Infected Controls/Plate 2_A3 Bright.jpg');
N_P2_A3= imresize(imcrop(N_P2_A3,[670 800 400 380]),[500 500]);
%--median filer--%
A3=medfilt2(rgb2gray(N_P2_A3));
figure
subplot(1,2,1)
imshow(N_P2_A3),title('Control Plate2 A3')
subplot(1,2,2)
imshow(A3),title('median filtered Control Plate2 A3')


N_P2_A5 = imread('./Non-Infected Controls/Plate 2_A5 Bright.jpg');
N_P2_A5= imresize(imcrop(N_P2_A5,[808 685 384 402]),[500 500]);
A5=medfilt2(rgb2gray(N_P2_A5));
figure
subplot(1,2,1)
imshow(N_P2_A5),title('Control Plate2 A3')
subplot(1,2,2)
imshow(A5),title('median filtered Control Plate2 A5')
%---Read an image into the workspace. convert the image from the RGB color space to the grayscale.%
Z_P2_A2 = imread('./ZIKV Infected/Plate 2_A2 Bright.jpg');
Z_P2_A2= imresize(imcrop(Z_P2_A2,[800 600 500 650]),[500 500]);

%--median filer, attenuate noise without blurring the images--%
A2=medfilt2(rgb2gray(Z_P2_A2));
figure
subplot(1,2,1)
imshow(Z_P2_A2),title('Zika Plate2 A2')
subplot(1,2,2)
imshow(A2),title('Median Zika Plate2 A2')

Z_P2_A4 = imread('./ZIKV Infected/Plate 2_A4 Bright.jpg');
Z_P2_A4= imresize(imcrop(Z_P2_A4,[900 700 450 450]),[500 500]);
%--median filer--%
A4=medfilt2(rgb2gray(Z_P2_A4));
figure
subplot(1,2,1)
imshow(Z_P2_A4),title('Zika Plate2 A4')
subplot(1,2,2)
imshow(A4),title('Median Zika Plate2 A4')

%---unsharp mask,contrast between the cytoplasm, and nuclei and
%extracellular components were enhanced using an unsharp filter
H = fspecial('gaussian',15,10);
d1= double(A1);
d3= double(A3);
d5= double(A5);
d2=double(A2);
d4=double(A4);
G1 = d1-(filter2(H,d1)* 0.9);
G2 = d2-(filter2(H,d2)* 0.9);
G3 = d3-(filter2(H,d3)* 0.9);
G4 = d4-(filter2(H,d4)* 0.9);
G5 = d5-(filter2(H,d5)* 0.9);

%--- Global thresholding cytoplasm was white (or 1) and the nucleus and extracellular components were black (or 0)
 B1level=graythresh(G1);
 B2level=graythresh(G2);
 B3level=graythresh(G3);
 B4level=graythresh(G4);
 B5level=graythresh(G5);
 
 binary1= imbinarize(G1,B1level);
 binary2= imbinarize(G2,B2level);
 binary3= imbinarize(G3,B3level);
 binary4= imbinarize(G4,B4level);
 binary5= imbinarize(G5,B5level);
 
 figure
 montage({binary1,binary3,binary5,binary2,binary4},'Size',[1 5])
title("binary Control A1,Control A3,Control A5, Zika A2, Zika A4")
 %-fourier transform
f1 = fft2(binary1);
f2 = fft2(binary2);
f3 = fft2(binary3);
f4 = fft2(binary4);
f5 = fft2(binary5);
figure
montage({f1,f3,f5,f2,f4},'Size',[1 5])
title("Fourier transform Control A1,Control A3,Control A5, Zika A2, Zika A4")
%--log transform
f1=fftshift(log(abs(f1) + 1));
f2=fftshift(log(abs(f2) + 1));
f3=fftshift(log(abs(f3) + 1));
f4=fftshift(log(abs(f4) + 1));
f5=fftshift(log(abs(f5) + 1));

% [M,N]=size(f1);
%         for x = 1:M
%             for y = 1:N
%                 m1=double(f1(x,y));
%                 z1(x,y)=log10(1+m1); 
%             end
%         end
%         
% [M,N]=size(f2);
%         for x = 1:M
%             for y = 1:N
%                 m2=double(f2(x,y));
%                 z2(x,y)=log10(1+m2); 
%             end
%         end
%  ave1 = filter2(fspecial('average',5),fshift1);
%  ave2 = filter2(fspecial('average',5),fshift2);
% ave1 = filter2(fspecial('average',5),ave1);
% ave2 = filter2(fspecial('average',5),ave2);
%Line plot
 x1=f1(250,:);
 figure
  plot(real(x1))
 x2=f2(250,:);
 title('Control Plate2 A1')
figure
 plot(real(x2))
 x4=f4(250,:);
 title('Zika Plate2 A2')
 x3=f3(250,:);
 figure
 plot(real(x3))
 title('Control Plate2 A3')
 figure
 plot(real(x4))
 title('Zika Plate2 A4')
 x5=f5(250,:);
 figure
 plot(real(x5))
 title('Control Plate2 A5')

 

 