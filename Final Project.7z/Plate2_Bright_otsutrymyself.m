% close all;
% Z_P2_2=imread('./ZIKV Infected/Plate 2_A2 Bright.jpg');
% I= imcomplement(rgb2gray(Z_P2_2));
% 
% [I2,I3,bw,cc1,cell2,celldata2,RGB_labeled]= otsumyfunction(I,1);
% 
% montage({Z_P2_2,I,I2,I3,cell2,RGB_labeled},'Size',[1 6])
% title("Zika Plate 2 A2 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
% pause;
% %----------------------------------------------------------------------
% Z_P2_4=imread('./ZIKV Infected/Plate 2_A4 Bright.jpg');
% I= imcomplement(rgb2gray(Z_P2_4));
% 
% [I2,I3,bw,cc1,cell4,celldata4,RGB_labeled]= otsumyfunction(I,1);
% 
% montage({Z_P2_4,I,I2,I3,cell4,RGB_labeled},'Size',[1 6])
% title("Zika Plate 2 A4 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
% pause;
% %--------------------------------------------------------------------------
% N_P2_1=imread('./Non-Infected Controls/Plate 2_A1 Bright.jpg');
% I= imcomplement(rgb2gray(N_P2_1));
% 
%  [I2,I3,bw,cc1,cell1,celldata1,RGB_labeled]= otsumyfunction(I,2);
% 
% 
% montage({N_P2_1,I,I2,I3,cell1,RGB_labeled},'Size',[1 6])
% title("Control Plate 2_A1 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
% pause;
% 
% % %--------------------------------------------------------------------------
% N_P2_3=imread('./Non-Infected Controls/Plate 2_A3 Bright.jpg');
% I= imcomplement(rgb2gray(N_P2_3));
% 
% [I2,I3,bw,cc1,cell3,celldata3,RGB_labeled]= otsumyfunction(I,1);
% 
% 
% montage({N_P2_3,I,I2,I3,cell3,RGB_labeled},'Size',[1 6])
% title("Control Plate 2_A3 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")

 %--------------------------------------------------------------------------
N_P2_5=imread('./Non-Infected Controls/Plate 2_A5 Bright.jpg');
I= imcomplement(rgb2gray(N_P2_5));

[I2,I3,bw,cc1,cell5,celldata5,RGB_labeled]= otsumyfunction(I,1);


montage({N_P2_5,I,I2,I3,cell5,RGB_labeled},'Size',[1 6])
title("Control Plate 2_A5 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")

