%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P2_A2 = imread('./ZIKV Infected/Plate 2_A2 Dark.jpg');
Z_P2_A2_lab = rgb2lab(Z_P2_A2);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P2_A2_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P2_A2_imadjust = Z_P2_A2_lab;
Z_P2_A2_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P2_A2_imadjust = lab2rgb(Z_P2_A2_imadjust);

Z_P2_A2_histeq = Z_P2_A2_lab;
Z_P2_A2_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P2_A2_histeq = lab2rgb(Z_P2_A2_histeq);

Z_P2_A2_adapthisteq = Z_P2_A2_lab;
Z_P2_A2_adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
Z_P2_A2_adapthisteq = lab2rgb(Z_P2_A2_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({Z_P2_A2,Z_P2_A2_imadjust,Z_P2_A2_histeq,Z_P2_A2_adapthisteq},'Size',[1 4])
title("Original Image and Enhanced Images using imadjust, histeq, and adapthisteq")
%------------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P2_A4 = imread('./ZIKV Infected/Plate 2_A4 Dark.jpg');
Z_P2_A4_lab = rgb2lab(Z_P2_A4);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P2_A4_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P2_A4_imadjust = Z_P2_A4_lab;
Z_P2_A4_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P2_A4_imadjust = lab2rgb(Z_P2_A4_imadjust);

Z_P2_A4_histeq = Z_P2_A4_lab;
Z_P2_A4_histeq(:,:,1) = histeq(L)*max_luminosity;
Z_P2_A4_histeq = lab2rgb(Z_P2_A4_histeq);

Z_P2_A4_adapthisteq = Z_P2_A4_lab;
Z_P2_A4_adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
Z_P2_A4_adapthisteq = lab2rgb(Z_P2_A4_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({Z_P2_A4,Z_P2_A4_imadjust,Z_P2_A4_histeq,Z_P2_A4_adapthisteq},'Size',[1 4])
title("Original Image Z_P2_A4 and Enhanced Images using imadjust, histeq, and adapthisteq")

%---------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A1 = imread('./Non-Infected Controls/Plate 2_A1 Dark.jpg');
N_P2_A1_lab = rgb2lab(N_P2_A1);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A1_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P2_A1_imadjust = N_P2_A1_lab;
N_P2_A1_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P2_A1_imadjust = lab2rgb(N_P2_A1_imadjust);

N_P2_A1_histeq = N_P2_A1_lab;
N_P2_A1_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A1__histeq = lab2rgb(N_P2_A1_histeq);

N_P2_A1_adapthisteq = N_P2_A1_lab;
N_P2_A1__adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
N_P2_A1_adapthisteq = lab2rgb(N_P2_A1_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({N_P2_A1,N_P2_A1_imadjust,N_P2_A1_histeq,N_P2_A1_adapthisteq},'Size',[1 4])
title("Original Image N_P2_A1 and Enhanced Images using imadjust, histeq, and adapthisteq")

%--------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A3 = imread('./Non-Infected Controls/Plate 2_A3 Dark.jpg');
N_P2_A3_lab = rgb2lab(N_P2_A3);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A3_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P2_A3_imadjust = N_P2_A3_lab;
N_P2_A3_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P2_A3_imadjust = lab2rgb(N_P2_A3_imadjust);

N_P2_A3_histeq = N_P2_A3_lab;
N_P2_A3_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A3__histeq = lab2rgb(N_P2_A3_histeq);

N_P2_A3_adapthisteq = N_P2_A3_lab;
N_P2_A3__adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
N_P2_A3_adapthisteq = lab2rgb(N_P2_A3_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({N_P2_A3,N_P2_A3_imadjust,N_P2_A3_histeq,N_P2_A3_adapthisteq},'Size',[1 4])
title("Original Image N_P2_A3 and Enhanced Images using imadjust, histeq, and adapthisteq")

%---------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P2_A5 = imread('./Non-Infected Controls/Plate 2_A5 Dark.jpg');
N_P2_A5_lab = rgb2lab(N_P2_A5);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P2_A5_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P2_A5_imadjust = N_P2_A5_lab;
N_P2_A5_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P2_A5_imadjust = lab2rgb(N_P2_A5_imadjust);

N_P2_A5_histeq = N_P2_A5_lab;
N_P2_A5_histeq(:,:,1) = histeq(L)*max_luminosity;
N_P2_A5__histeq = lab2rgb(N_P2_A5_histeq);

N_P2_A5_adapthisteq = N_P2_A5_lab;
N_P2_A5__adapthisteq(:,:,1) = adapthisteq(L)*max_luminosity;
N_P2_A5_adapthisteq = lab2rgb(N_P2_A5_adapthisteq);

%---Display the original image and the three contrast adjusted images as a montage.---%
figure
montage({N_P2_A5,N_P2_A5_imadjust,N_P2_A5_histeq,N_P2_A5_adapthisteq},'Size',[1 4])
title("Original Image N_P2_A5 and Enhanced Images using imadjust, histeq, and adapthisteq")