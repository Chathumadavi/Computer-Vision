function [filteredIm] = MedianFiltering(im,mask)
    [mrow,mcol]=size(mask);
    remainder=rem(mrow,2);
    sum_mask=round(sum(mask(:)));
    [m,n]=size(im);
    
    if mrow == mcol && remainder==1 
        if mask(mask>0)
            if mrow==3 && mcol==3
                padded_im= padarray(im,[1 1],0,'both');
                for i=2:m+1
                    for j=2:n+1
                        x=1;
                        k=1;
                        for a=j-1:j+1
                              
                            l=1;
                            for b= i-1:i+1
                                val=mask(k,l);
                                y= x+(val-1);
                                ar(1,x:y)=padded_im(b,a);
                                x=x+mask(k,l);
                                l=l+1;
                            end
                            k=k+1;     
                        end
                        filteredIm(i,j)=median(ar);
                    end
                end
                filteredIm = filteredIm(2:end, 2:end);
            elseif mrow==5 && mcol==5
                padded_im= padarray(im,[2 2],0,'both');
                for i=3:m+2
                    for j=3:n+2
                        x=1;
                        k=1;  
                        
                        for a=j-1:j+1
                            l=1;
                            for b= i-1:i+1
                                val=mask(k,l);
                                y= x+(val-1);
                                ar(1,x:y)=padded_im(b,a);
                                x=x+mask(k,l);
                                l=l+1;
                            end
                            k=k+1;     
                        end
                        filteredIm(i,j)=median(ar);
                    end
                end
                filteredIm = filteredIm(3:end, 3:end);
            end
        end
     elseif mrow ~= mcol 
        disp("Error: Mask is not a square");
    
    elseif rem(mrow,2)==0 || rem(mcol,2)==0
        disp("Error: Mask�s dimension is not an odd number");
    
    elseif mask(mask<0) 
        disp("Doesn't posses properties of low-pass filter")
    end
    
end