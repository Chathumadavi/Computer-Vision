%---Loading ZIKV Infected Plate 1 images---%
Z_P1_1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
%---Converting into grayscale---%
g_Z_P1_1=rgb2gray(Z_P1_1);
%---Increase contrast of image---%
im_Z_P1_1=imadjust(g_Z_P1_1);

%---Median filtering---%
mask = ones([3 3]);
[c_Z_P1_1] = MedianFiltering(im_Z_P1_1,mask);

level = graythresh(c_Z_P1_1);
b_Z_P1_1 = im2bw(c_Z_P1_1,level); %binary image

figure
montage({Z_P1_1,im_Z_P1_1,c_Z_P1_1,b_Z_P1_1},'Size',[1 4])
title("Zika Plate 1 A1 Bright,Enhanced Images using imadjust, filtered Image,Binary Image")
pause;

 Z_P1_5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
%---Converting into grayscale---%
 g_Z_P1_5=rgb2gray(Z_P1_5);
 %---Increase contrast of image---%
 im_Z_P1_5=imadjust(g_Z_P1_5);
 
 mask = ones([3 3]);
 [c_Z_P1_5] = MedianFiltering(im_Z_P1_5,mask);
 
 
 level = graythresh(c_Z_P1_5);
 b_Z_P1_5 = im2bw(c_Z_P1_5,level); %thresholding
 figure;
 montage({Z_P1_5,im_Z_P1_5,c_Z_P1_5,b_Z_P1_5},'Size',[1 4])
 title("Zika Plate 1 A5 Bright and Enhanced Images using imadjust, filtered Image,Binary Zika Plate 1 A5 Bright")
 pause;

 %---Loading Non-Infected Plate 1 images---%
 N_P1_2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
 %---Converting into grayscale---%
 g_N_P1_2=rgb2gray(N_P1_2);
 %---Increase contrast of image---%
 im_N_P1_2=imadjust(g_N_P1_2);
 %---Median filtering---%
 mask = ones([3 3]);
 [c_N_P1_2] = MedianFiltering(im_N_P1_2,mask);


%---Thresholding---%
 level = graythresh(c_N_P1_2);
 b_N_P1_2 = im2bw(c_N_P1_2,level);

figure;
 montage({N_P1_2,im_N_P1_2,c_N_P1_2,b_N_P1_2},'Size',[1 4])
 title("Control Plate 1 A2 Bright and Enhanced Images using imadjust, filtered ImageBinary Image Control Plate 1 A2 Bright")
 pause;
 
 N_P1_4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
 %---Converting into grayscale---%
 g_N_P1_4=rgb2gray(N_P1_4);
 %---Increase contrast of image---%
 im_N_P1_4=imadjust(g_N_P1_4);

 mask = ones([3 3]);
 [c_N_P1_4] = MedianFiltering(im_N_P1_4,mask);
 
 level = graythresh(c_N_P1_4);
 b_N_P1_4 = im2bw(c_N_P1_4,level);%binary image

 
 figure;
 montage({N_P1_4,im_N_P1_4,c_N_P1_4,b_N_P1_4},'Size',[1 4])
 title("Control Plate 1 A4 Bright and Enhanced Images using imadjust, filtered Image,Binary Image Control Plate 1 A4 Bright")
 pause;
close all;
clear all;