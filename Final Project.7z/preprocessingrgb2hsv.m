%---Loading ZIKV Infected Plate 1 images---%
Z_P1_1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
%---Converting into hsvscale---%
g_Z_P1_1=rgb2hsv(Z_P1_1);

%---Thresholding---%
level = graythresh(g_Z_P1_1(:,:,1));
b_Z_P1_1_h = im2bw(g_Z_P1_1(:,:,1),level);

level = graythresh(g_Z_P1_1(:,:,2));
b_Z_P1_1_s = im2bw(g_Z_P1_1(:,:,2),level);

level = graythresh(g_Z_P1_1(:,:,3));
b_Z_P1_1_v = im2bw(g_Z_P1_1(:,:,3),level);


%---Increase contrast of image---%
c_Z_P1_1=histeq(g_Z_P1_1);

figure
montage({Z_P1_1,g_Z_P1_1,c_Z_P1_1,g_Z_P1_1(:,:,1),g_Z_P1_1(:,:,2),g_Z_P1_1(:,:,3),b_Z_P1_1_h,b_Z_P1_1_s,b_Z_P1_1_v},'Size',[3 3])
title("Zika Plate 1 A1 Bright,HSV,HistEq,Zika Plate 1 A1 Bright H_Space,S_Space,V_Space,Binary:ZP1_1_H_Space, Binary:ZP1_1_S_Space,Binary:ZP1_1_V_Space")

pause;

Z_P1_5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
%---Converting into hsvscale---%
g_Z_P1_5=rgb2hsv(Z_P1_5);

%---Thresholding---%
level = graythresh(g_Z_P1_5(:,:,1));
b_Z_P1_5_h = im2bw(g_Z_P1_5(:,:,1),level);

level = graythresh(g_Z_P1_5(:,:,2));
b_Z_P1_5_s = im2bw(g_Z_P1_5(:,:,2),level);

level = graythresh(g_Z_P1_5(:,:,3));
b_Z_P1_5_v = im2bw(g_Z_P1_5(:,:,3),level);



%---Increase contrast of image---%
c_Z_P1_5=histeq(g_Z_P1_5);

figure
montage({Z_P1_5,g_Z_P1_5,c_Z_P1_5,g_Z_P1_5(:,:,1),g_Z_P1_5(:,:,2),g_Z_P1_5(:,:,3),b_Z_P1_5_h,b_Z_P1_5_s,b_Z_P1_5_v},'Size',[3 3])
title("Zika Plate 1 A5 Bright,HSV,HistEq,Zika Plate 1 A5 Bright H_Space,S_Space,V_Space,Binary:ZP1_5_H_Space,S_Space,Binary:V_Space")
pause;

%---Loading Non-Infected Plate 1 images---%
 N_P1_2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
%---Converting into hsvscale---%
 g_N_P1_2=rgb2hsv(N_P1_2);

level = graythresh(g_N_P1_2(:,:,1));
b_N_P1_2_h = im2bw(g_N_P1_2(:,:,1),level);

level = graythresh(g_N_P1_2(:,:,2));
b_N_P1_2_s = im2bw(g_N_P1_2(:,:,2),level);

level = graythresh(g_N_P1_2(:,:,3));
b_N_P1_2_v = im2bw(g_N_P1_2(:,:,3),level);


%---Increase contrast of image---%
c_N_P1_2=histeq(g_N_P1_2);

figure
montage({N_P1_2,g_N_P1_2,c_N_P1_2,g_N_P1_2(:,:,1),g_N_P1_2(:,:,2),g_N_P1_2(:,:,3),b_N_P1_2_h,b_N_P1_2_s,b_N_P1_2_v},'Size',[3 3])
title("Zika Plate 1 A2 Bright,HSV,HistEq,Zika Plate 1 A2 Bright H_Space,S_Space,V_Space,Binary:NP1_2_H_Space, S_Space,V_Space")
pause;

N_P1_4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
%---Converting into hsvscale---%
g_N_P1_4=rgb2hsv(N_P1_4);

%---Thresholding---%
level = graythresh(g_N_P1_4(:,:,1));
b_N_P1_4_h = im2bw(g_N_P1_4(:,:,1),level);

level = graythresh(g_N_P1_4(:,:,2));
b_N_P1_4_s = im2bw(g_N_P1_4(:,:,2),level);

level = graythresh(g_N_P1_4(:,:,3));
b_N_P1_4_v = im2bw(g_N_P1_4(:,:,3),level);

%---Increase contrast of image---%
c_N_P1_4=histeq(g_N_P1_4);

figure
montage({N_P1_4,g_N_P1_4,c_N_P1_4,g_N_P1_4(:,:,1),g_N_P1_4(:,:,2),g_N_P1_4(:,:,3),b_N_P1_4_h,b_N_P1_4_s,b_N_P1_4_v},'Size',[3 3])
title("Zika Plate 1 A4 Bright,HSV,HistEq,Zika Plate 1 A4 Bright H_Space,S_Space,V_Space,Binary:NP1_4_H_Space, S_Space,V_Space")
pause;

close all;
clear;