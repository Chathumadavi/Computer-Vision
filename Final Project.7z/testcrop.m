Z_P1_A1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
Z_P1_A5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
N_P1_A2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
N_P1_A4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
Z_P1_A1= imresize(imcrop(Z_P1_A1,[550 500 575 560]),[500 500]);
N_P1_A2= imresize(imcrop(N_P1_A2,[550 480 670 550]),[500 500]);
N_P1_A4= imresize(imcrop(N_P1_A4,[600 400 800 650]),[500 500]);
Z_P1_A5= imresize(imcrop(Z_P1_A5,[830 330 630 700]),[500 500]);

