%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P1_A1 = imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
Z_P1_A1_lab = rgb2lab(Z_P1_A1);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P1_A1_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P1_A1_imadjust = Z_P1_A1_lab;
Z_P1_A1_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P1_A1_imadjust = lab2rgb(Z_P1_A1_imadjust);

F=Z_P1_A1_imadjust;
r=F(:,:,1);
g=F(:,:,2);
b=F(:,:,3);
c=1-r;
m=1-g;
y=1-b;
P1_A1=cat(3,c,m,y);

figure
subplot(2,3,1)
imshow(P1_A1);title('CMYK')
subplot(2,3,2)
imshow(P1_A1(:,:,1));title('C')
subplot(2,3,3)
imshow(P1_A1(:,:,2));title('M')
subplot(2,3,4)
imshow(P1_A1(:,:,3));title('Y')
subplot(2,3,5)
imshow(Z_P1_A1);title('Original')
subplot(2,3,6)
imshow(Z_P1_A1_imadjust);title('Adjusted')
pause;

level = graythresh(P1_A1(:,:,2));
b_Z_P1_1 = im2bw(P1_A1(:,:,2),level);
figure
imshow(b_Z_P1_1);title('Binary image M:P1_1')
pause;


%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
Z_P1_A5 = imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
Z_P1_A5_lab = rgb2lab(Z_P1_A5);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = Z_P1_A5_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
Z_P1_A5_imadjust = Z_P1_A5_lab;
Z_P1_A5_imadjust(:,:,1) = imadjust(L)*max_luminosity;
Z_P1_A5_imadjust = lab2rgb(Z_P1_A5_imadjust);

F=Z_P1_A5_imadjust;
r=F(:,:,1);
g=F(:,:,2);
b=F(:,:,3);
c=1-r;
m=1-g;
y=1-b;
P1_A5=cat(3,c,m,y);

figure
subplot(2,3,1)
imshow(P1_A5);title('CMYK')
subplot(2,3,2)
imshow(P1_A5(:,:,1));title('C')
subplot(2,3,3)
imshow(P1_A5(:,:,2));title('M')
subplot(2,3,4)
imshow(P1_A5(:,:,3));title('Y')
subplot(2,3,5)
imshow(Z_P1_A5);title('Original')
subplot(2,3,6)
imshow(Z_P1_A5_imadjust);title('Adjusted')
pause;



level = graythresh(P1_A5(:,:,2));
b_Z_P1_5 = im2bw(P1_A5(:,:,2),level);
figure
imshow(b_Z_P1_5);title('Binary image M:P1_5')
pause;

%---------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P1_A2 = imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
N_P1_A2_lab = rgb2lab(N_P1_A2);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P1_A2_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P1_A2_imadjust = N_P1_A2_lab;
N_P1_A2_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P1_A2_imadjust = lab2rgb(N_P1_A2_imadjust);

F=N_P1_A2_imadjust;
r=F(:,:,1);
g=F(:,:,2);
b=F(:,:,3);
c=1-r;
m=1-g;
y=1-b;
P1_A2=cat(3,c,m,y);

figure
subplot(2,3,1)
imshow(P1_A2);title('CMYK')
subplot(2,3,2)
imshow(P1_A2(:,:,1));title('C')
subplot(2,3,3)
imshow(P1_A2(:,:,2));title('M')
subplot(2,3,4)
imshow(P1_A2(:,:,3));title('Y')
subplot(2,3,5)
imshow(N_P1_A2);title('Original')
subplot(2,3,6)
imshow(N_P1_A2_imadjust);title('Adjusted')
pause;



level = graythresh(P1_A2(:,:,2));
b_Z_P1_2= im2bw(P1_A2(:,:,2),level);
figure
imshow(b_Z_P1_2);title('Binary image M:P1_2')
pause;
%--------------------------------------------------------------------------------------------------------
%---Read an image into the workspace. convert the image from the RGB color space to the L*a*b* color space.%
N_P1_A4 = imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
N_P1_A4_lab = rgb2lab(N_P1_A4);

%---The values of luminosity span a range from 0 to 100. ---%
%---Scale the values to the range [0 1], which is the expected range of images with data type double.---%
max_luminosity = 100;
L = N_P1_A4_lab(:,:,1)/max_luminosity;

%---Perform the three types of contrast adjustment on the luminosity channel, and keep the a* and b* channels unchanged.---%
%---Convert the images back to the RGB color space.---%
N_P1_A4_imadjust = N_P1_A4_lab;
N_P1_A4_imadjust(:,:,1) = imadjust(L)*max_luminosity;
N_P1_A4_imadjust = lab2rgb(N_P1_A4_imadjust);

F=N_P1_A4_imadjust;
r=F(:,:,1);
g=F(:,:,2);
b=F(:,:,3);
c=1-r;
m=1-g;
y=1-b;
P1_A4=cat(3,c,m,y);

figure
subplot(2,3,1)
imshow(P1_A4);title('CMYK')
subplot(2,3,2)
imshow(P1_A4(:,:,1));title('C')
subplot(2,3,3)
imshow(P1_A4(:,:,2));title('M')
subplot(2,3,4)
imshow(P1_A4(:,:,3));title('Y')
subplot(2,3,5)
imshow(N_P1_A4);title('Original')
subplot(2,3,6)
imshow(N_P1_A4_imadjust);title('Adjusted')
pause;



level = graythresh(P1_A4(:,:,2));
b_Z_P1_4 = im2bw(P1_A4(:,:,2),level);
figure
imshow(b_Z_P1_4);title('Binary image M:P1_4')