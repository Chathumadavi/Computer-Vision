%  Z_P1_A5=imread('./ZIKV Infected/Plate 1_A5 Bright.jpg');
%  Z_P1_A5= imresize(imcrop(Z_P1_A5,[830 330 630 700]),[500 500]);
% %---Converting into grayscale---%
%  g_Z_P1_5=rgb2gray(Z_P1_A5);
%  %---Increase contrast of image---%
%  im_Z_P1_5=imadjust(g_Z_P1_5);
%  
% 
% figure
% for n = 2 : 4 
% IDX5 = otsu(im_Z_P1_5,n); 
% subplot(3,2,n) 
% imagesc(IDX5), axis image off 
% title(['Plate 1_A5 Bright n = ' int2str(n)],'FontWeight','bold') 
% end
% 
% % I= imcomplement(IDX5);
% A5= regionprops(IDX5,'basic');
% 
% % [I2,I3,bw,cc1,cell,celldata,RGB_labeled]= otsumyfunction(I,4);
% % montage({Z_P1_5,I,I2,I3,cell,RGB_labeled},'Size',[1 6])
% % title("Zika Plate 1 A1 Bright,Complement, Enhanced Image,Imadjust image, Object,RGB Image")
% pause;
% %-----------------------------------------
%  Z_P1_A1=imread('./ZIKV Infected/Plate 1_A1 Bright.jpg');
%  Z_P1_A1= imresize(imcrop(Z_P1_A1,[550 500 575 560]),[500 500]);
% %---Converting into grayscale---%
%  g_Z_P1_1=rgb2gray(Z_P1_A1);
%  %---Increase contrast of image---%
%  im_Z_P1_1=imadjust(g_Z_P1_1);
%  
% 
% 
% 
% figure
% for n = 2:4
% IDX1 = otsu(im_Z_P1_1,n); 
% subplot(3,2,n)
% imagesc(IDX1), axis image off 
% title(['Plate 1_A1 Bright n = ' int2str(n)],'FontWeight','bold') 
% end
% A1= regionprops(IDX1,'basic');
 
% %-----------------------------------------
%   N_P1_A2=imread('./Non-Infected Controls/Plate 1_A2 Bright.jpg');
%   N_P1_A2= imresize(imcrop(N_P1_A2,[550 480 670 550]),[500 500]);
% %---Converting into grayscale---%
%  g_N_P1_2=rgb2gray(N_P1_A2);
%  %---Increase contrast of image---%
%  im_N_P1_2=imadjust(g_N_P1_2);
%  
% 
% 
% figure
% for n = 2:4
% IDX2 = otsu(im_N_P1_2,n); 
% subplot(3,2,n)
% imagesc(IDX2), axis image off 
% title(['Plate 1_A2 Bright n = ' int2str(n)],'FontWeight','bold') 
% end
% A2= regionprops(IDX2,'basic');
% 
% 
% %-----------------------------------------
 N_P1_A4=imread('./Non-Infected Controls/Plate 1_A4 Bright.jpg');
 N_P1_A4= imresize(imcrop(N_P1_A4,[600 400 800 650]),[500 500]);
%---Converting into grayscale---%
 g_N_P1_4=rgb2gray(N_P1_A4);
 %---Increase contrast of image---%
 im_N_P1_4=imadjust(g_N_P1_4);
 


figure
for n = 2:4 
IDX4 = otsu(im_N_P1_4,n); 
subplot(3,2,n)
imagesc(IDX4), axis image off 
title(['Plate 1_A4 Bright n = ' int2str(n)],'FontWeight','bold') 
end

A4= regionprops(IDX4,'basic');
