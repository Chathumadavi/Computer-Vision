%---Chathumadavi Ediriweera, Assignment 2---%

%---Defining CalHist function---%
function Calhist(inputIm,varargin)
 
     x = unique(inputIm);
     [xr,xc]=size(x);
     y = zeros([xr,xc]);
     [row,col] = size(inputIm);
     for k= 1:xr
         for l=1:xc
          for i=1:row
             for j=1:col
                 if inputIm(i,j)==x(k,l)
                    y(k,l)=y(k,l)+1; 
                 end
             end
          end
         end
     end
     for k=1:xr
         for l=1:xc
          y1(k,l)=y(k,l)./(row*col);
         end
     end
 if varargin{1} == 1
     figure;
     bar(x,y)
     %histogram(inputIm)
     title('Histogram')
     xlabel('Gray Level')
     ylabel('Pixel Count')
 elseif varargin{1} == 2
     figure;
     bar(x,y1)
     %histogram(inputIm,'Normalization','probability')
     title('Normalized Histogram')
     xlabel('Gray Level')
     ylabel('Normalized Pixel Count')
 elseif varargin{1} == 3
     figure;
     subplot(2,1,1)
     bar(x,y)
     %histogram(inputIm)
     title('Histogram')
     xlabel('Gray Level')
     ylabel('Pixel Count')
     
     subplot(2,1,2)
     bar(x,y1)
     %histogram(inputIm,'Normalization','probability')
     title('Normalized Histogram')
     xlabel('Gray Level')
     ylabel('Normalized Pixel Count')
 end
end