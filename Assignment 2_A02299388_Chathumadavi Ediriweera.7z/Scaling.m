%---Chathumadavi Ediriweera, Assignment 2---%

%---Defining Scaling function---%
function [scaledIm, transFunc] = Scaling(inputIm, range)
[row,col] = size(inputIm);
scaledIm = zeros(row,col);
inputIm = double(inputIm);
uniqueIm = unique(inputIm);

minIn = min(uniqueIm);
maxIn = max(uniqueIm);
n= maxIn-minIn+1;

transFunc = zeros([n,1]);
minOut = range(1,1);
maxOut = range(1,2);
gradient= (maxOut-minOut)./(maxIn-minIn);
intercept= minOut -(gradient*minIn);
for i=1:n
   transFunc(i,1)= round(gradient*uniqueIm(i,1)+intercept);
   if transFunc(i,1)< minOut || transFunc(i,1)> maxOut
       warning('Out of Range')
   end
end

 for i = 1:row
    for j=1:col
        for k = 1:n
            if inputIm(i,j)==uniqueIm(k,1)
                scaledIm(i,j)=transFunc(k,1);
            end
        end
    end
 end

scaledIm = uint8(scaledIm);
end
