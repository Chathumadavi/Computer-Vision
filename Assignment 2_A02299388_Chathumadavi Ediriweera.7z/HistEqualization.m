%---Chathumadavi Ediriweera, Assignment 2---%

%---Defining HistEqualization function---%
function [enhancedIm, transFunc] = HistEqualization(inputIm)
%Calling Scaling Function within the function
%range= [0 255];
%[scaledIm, tFunc] = Scaling(inputIm, range);
%[row,col] = size(scaledIm);
[row,col] = size(inputIm);
enhancedIm = zeros(row,col);

%x = unique(scaledIm);
x = unique(inputIm);
[xr,xc]=size(x);
y = zeros([xr,xc]);
y1= zeros([xr,xc]);
Cm= zeros([xr,xc]);
transFunc= zeros([xr,xc]);
%---Counting number of pixels per each intensity value---%
      for k = 1:xr
         for l=1:xc
          for i=1:row
             for j=1:col
                 %if scaledIm(i,j)==x(k,l)
                 if inputIm(i,j)==x(k,l)
                    y(k,l)=y(k,l)+1; 
                 end
             end
          end
         end
      end
     
     for k=1:xr
         for l=1:xc
       %---Calculating probability/normalized values---%
          y1(k,l)=y(k,l)./(row*col);
       %---Calculating cumulative values---%
          Cm(k,l)= sum(y1(1:k,l));  
       %---Tranforming intensity values---%
          transFunc(k,l) = round(Cm(k,l)*255);          
         end
     end
       
      
%---Mapping new intensity on to old intensity values---%     
      for i = 1:row
        for j=1:col
          for k = 1:xr
              for l=1:xc
                %if scaledIm(i,j)==x(k,l)
                if inputIm(i,j)==x(k,l)
                    enhancedIm(i,j)=transFunc(k,l);
                end
              end
          end
        end
      end
%---Converting the image into unit8---%
enhancedIm = uint8(enhancedIm);
end