%---Chathumadavi Ediriweera, Assignment 2---%

%---Load the image Food.jpg into a variable food---%
food = imread('Food.jpg');

%--- Defining new range---%
range = [0 255];

%---Calling Scaling function---%
[scaledFood, transFunc] = Scaling(food, range);

x= unique(food);
y= transFunc;
figure;
plot(x,y);
title('Transform Function');
xlabel('Old Range');
ylabel('New Range');
%---Finish Solving Problem 1---%
pause;

%---Defining maximum and minimum, input and output ranges---%
min_x = double(min(x));
low_in = min_x./255;
max_x = double(max(x));
high_in = max_x./255;
low_out = range(1,1)/255;
high_out = range(1,2)/255;
%---Calling imajust built-in function---%
matScaledFood = imadjust(food,[low_in high_in],[low_out high_out]);

%---Display the scaled image and built-in scaled image---%
figure;
subplot(1,2,1)
imshow(scaledFood)
title('Scaling Function: Scaled Image')

subplot(1,2,2)
imshow(matScaledFood)
title('Imadjust Function: Scaled Image')

%---Finish Solving Problem 2---%
pause;

%---Calling Calhist Function---%
Calhist(scaledFood,3);
%Calhist(matScaledFood,2);
%Calhist(matScaledFood,1);

%---Finish Solving Problem 3---%
pause;

%---Calling HistEqualization Function---%
[equalizedFood, histTransFunc] = HistEqualization(food);

disp(histTransFunc);
%---Display running time---%
f = @() HistEqualization(food);
running_time=timeit(f)
%---Finish Solving Problem 4---%
pause;

%---Calling Matlab built-in function---%
[matEqualizedFood,T]= histeq(food);
transformFunction=uint8(T*255);
%transformFunction=transformFunction(:);
%disp(size(transformFunction));
%disp(transformFunction);




%---Display running time---%
g= @() histeq(food);
h= @() uint8(T*255);
mat_run_time= timeit(g)+ timeit(h)

%---Display enhanced images---%
figure;
subplot(1,2,1)
imshow(equalizedFood);
title('Enhanced Image');

subplot(1,2,2)
imshow(matEqualizedFood);
title('Matlab Enhanced Image')
pause;

%---Plot Transform functions---%
figure;
subplot(1,2,1)
x=unique(food);
y=histTransFunc;
plot(x,y);
title('Histogram Equalization Transform Function');
xlabel('Old Range');
ylabel('New Range');

subplot(1,2,2)
plot(0:255,transformFunction);
title('Matlab Histogram Equalization Transform Function');
xlabel('Old Range');
ylabel('New Range');
pause;
 
%---Comparison of the running times---%
DifferenceOfRunningTimes=running_time-mat_run_time

%---Comparison of the histogram equalization transform functions---%
tf = isequal(histTransFunc,transformFunction)

%---Details about the function used in Problem 5---%
disp('[J,T] = histeq(I) returns the gray scale transformation that maps gray levels in the intensity image I to gray levels in J.')
help histeq

%---Finish Solving Problem 5---%
pause;

%---Close all figures and clear all variables---%
clear;
close all;

