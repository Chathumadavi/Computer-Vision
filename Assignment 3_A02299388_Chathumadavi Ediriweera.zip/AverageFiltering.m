%---Chathumadavi Ediriweera, Assignment 3---%

%---Defining AverageFileriing function---%
function [filteredIm] = AverageFiltering (im,mask)
    %filteredIm=size(im);
    [mrow,mcol]=size(mask);
    remainder=rem(mrow,2);
    sum_mask=round(sum(mask(:)));
    [m,n]=size(im);
    
    if mrow == mcol && remainder==1 && sum_mask == 1 && issymmetric(mask)==1
        if mask(mask>0)
            if mrow==3 && mcol==3
                padded_im= padarray(im,[1 1],0,'both');
                for i=2:m+1
                    for j=2:n+1
                        filteredIm(i,j)=round(padded_im(i-1,j-1)*mask(1,1)+padded_im(i,j-1)*mask(1,2)+padded_im(i+1,j-1)*mask(1,3)+ padded_im(i-1,j)*mask(2,1)+padded_im(i,j)*mask(2,2)+padded_im(i+1,j)*mask(2,3)+ padded_im(i-1,j+1)*mask(3,1)+padded_im(i,j+1)*mask(3,2)+padded_im(i+1,j+1)*mask(3,3));
                    end
                end
                   
                filteredIm = filteredIm(2:end, 2:end);
                
            elseif mrow==5 && mcol==5
                padded_im= padarray(im,[2 2],0,'both');
                for i=3:m+2
                    for j=3:n+2
                        filteredIm(i,j)=round(padded_im(i-2,j-2)*mask(1,1)+padded_im(i-1,j-2)*mask(1,2)+padded_im(i,j-2)*mask(1,3)+padded_im(i+1,j-2)*mask(1,4)+padded_im(i+2,j-2)*mask(1,5)+ padded_im(i-2,j-1)*mask(2,1)+padded_im(i-1,j-1)*mask(2,2)+padded_im(i,j-1)*mask(2,3)+ padded_im(i+1,j-1)*mask(2,4)+ padded_im(i+2,j-1)*mask(2,5)+ padded_im(i-2,j)*mask(3,1)+padded_im(i-1,j)*mask(3,2)+ padded_im(i,j)*mask(3,3)+ padded_im(i+1,j)*mask(3,4)+ padded_im(i+2,j)*mask(3,5)+ padded_im(i-2,j+1)*mask(4,1)+ padded_im(i-1,j+1)*mask(4,2)+ padded_im(i,j+1)*mask(4,3)+ padded_im(i+1,j+1)*mask(4,4)+ padded_im(i+2,j+1)*mask(4,5)+ padded_im(i-2,j+2)*mask(5,1)+ padded_im(i-1,j+2)*mask(5,2)+ padded_im(i,j+2)*mask(5,3)+ padded_im(i+1,j+2)*mask(5,4)+ padded_im(i+2,j+2)*mask(5,5));
                        
                    end
                end
                filteredIm = filteredIm(3:end, 3:end);
            end
         
           
            
        end
     elseif mrow ~= mcol 
        disp("Error: Mask is not a square");
    
    elseif rem(mrow,2)==0 || rem(mcol,2)==0
        disp("Error: Mask�s dimension is not an odd number");
    
    elseif mask(mask<0)|| sum(mask(mask(:)))~=1 || issymmetric(mask)==0
        disp("Doesn't posses properties of low-pass filter")
    end
    
end