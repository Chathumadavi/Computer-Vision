%---Chathumadavi Ediriweera, Assignment 3---%

%---Defining CalEdgehist function---%

function edgeHist = CalEdgeHist(im, bin)
Sobelx=[-1 -2 -1;0 0 0;1 2 1];
Sobely=[-1 0 1;-2 0 2;-1 0 1];
p_im= padarray(im,[1 1],0,'both');
[m,n]=size(im);

for i=2:m+1
     for j=2:n+1
          filteredImX(i,j)= double((p_im(i-1,j+1)+(2*p_im(i,j+1))+p_im(i+1,j+1))-(p_im(i-1,j-1)+(2*p_im(i,j-1))+p_im(i+1,j-1)));
          filteredImY(i,j)= double((p_im(i+1,j-1)+(2*p_im(i+1,j))+p_im(i+1,j+1))-(p_im(i-1,j-1)+(2*p_im(i-1,j))+p_im(i-1,j+1)));
          angle(i,j) = atan(filteredImX(i,j)./filteredImY(i,j))*(360/pi);
          
     end
end 

  angle = atan(filteredImX./filteredImY)*(360/pi);
          step = 360/bin;
          Q=angle./step;
          Q=round(Q);
          for i=2:m+1
              for j=2:n+1
                 R=rem(angle(i,j),step);
                 if R>0
                    bin_no=Q+1;
                    
                 else
                    bin_no=Q;
                   
                 end
              end
          end
 angle = angle(2:end, 2:end);
 bin_no= bin_no(2:end, 2:end);
 for i=1:bin
  c(1,i)=sum(bin_no(:) == i);
 end
edgeHist= c;
 
end