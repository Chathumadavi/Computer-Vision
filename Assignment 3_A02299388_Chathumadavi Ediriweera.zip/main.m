%---Chathumadavi Ediriweera, Assignment 3---%

%---Load the image---%
Circuit = imread('Circuit.jpg');
figure;
subplot(1,3,1);
imshow(Circuit);
title('Original Image')

%---Define 3-by-3 mask---%
mask = [1 2 1;2 4 2;1 2 1];
total= sum(mask(mask(:)));
avgmask = mask./total;



%---Calling AverageFiltering function for 3-by-3 mask---%
[filteredIm1] = AverageFiltering (Circuit,avgmask);

subplot(1,3,2)
imshow(filteredIm1)
title('Filtered Image:Weighted 3-by3 Averaging Filter');

%---Define 5-by-5 standard mask---%
st_mask = ones([5 5]);
total= sum(st_mask(st_mask(:)));
st_avg_mask = st_mask./total;


%---Calling AverageFiltering function for standard 5-by-5 mask---%
[filteredIm2] = AverageFiltering (Circuit,st_avg_mask);
subplot(1,3,3)
imshow(filteredIm2)
title('Filtered Image:Standard 5-by-5 Averaging Filter');

%---Finish Solving Problem 1---%
pause;

%---Calling MedianFiltering function for 3-by-3 Median filter---%
[filteredIm3] = MedianFiltering (Circuit,mask);

%---Calling MedianFiltering function for Standard 5-by-5 Median filter---%
[filteredIm4] = MedianFiltering (Circuit,st_mask);

%---Displaying Original and Median Filtered Images---%
figure;
subplot(1,3,1);
imshow(Circuit);
title('Original Image');
subplot(1,3,2);
imshow(filteredIm3);
title('Weighted 3�3 median filter')
subplot(1,3,3);
imshow(filteredIm4);
title('Standard 5x5 median filter')

%---Finish Solving Problem 2---%
pause;

OriginalIm= imread('Moon.jpg');
figure;
subplot(2,2,1)
imshow(OriginalIm);
title('Original Image')

SLF=[1 1 1;1 -8 1;1 1 1]; %// Change - Centre is negative
%filteredIm=uint8(filter2(SLF,OriginalIm,'same'));

a = im2double(imread('Moon.jpg')); 
%lap = [-1 -1 -1; -1 8 -1; -1 -1 -1]; %// Change - Centre is now positive
result= imfilter(a, SLF, 'conv'); 
minR = min(result(:));
maxR = max(result(:));
scaledIm = (result - minR) / (maxR - minR);
filteredIm=uint8(result);
EnhancedIm=OriginalIm-filteredIm;
subplot(2,2,2)
imshow(result)
title('Filtered Image')
subplot(2,2,3)
imshow(scaledIm)
title('Scaled Filtered Image')
subplot(2,2,4)
imshow(EnhancedIm)
title('Enhanced Image')

%---Finish Solving Problem 3---%
pause;

%---Problem II: Exercises on Edge Detectors in the Spatial Domain---%
Rice=imread('Rice.jpg');
Gx=[-1 -2 -1;0 0 0;1 2 1];
Gy=[-1 0 1;-2 0 2;-1 0 1];

filteredImX= conv2(Rice,Gx,'same');
filteredImY= conv2(Rice,Gy,'same');
Mag= abs(filteredImX)+abs(filteredImY);

     

Mag = Mag(2:end, 2:end);
cutoff = sum(Mag(:),'double') / numel(Mag);

[r,c]=size(Mag);
new_im=zeros([r c]);
for i=1:r
    for j=1:c
        if Mag(i,j)> cutoff
            new_im(i,j)=1;
        else
            new_im(i,j)=0;
        end
    end
end   

disp('Threshold value is deteremined by cutoff = sum(Mag(:),double) / numel(Mag)')

%---Finish Solving Problem II Question 1---%
pause;

%--- Problem II Question 2---%
bin=18;
edgeHist = CalEdgeHist(Rice, bin);
figure;
subplot(1,3,1);
imshow(Rice);
title('Original Image');
subplot(1,3,2);
imshow(new_im);
title('Edge Detection');
subplot(1,3,3);
bar(1:bin,edgeHist);
title('Edge Histogram')

%---Finish Solving Problem II Question 2---%
pause;

%--- Problem III---%

%---Calling RmvStr Function---%
Text=imread('Text.gif');
Text1=imread('Text1.gif');
Text2=imread('Text2.jpg');
ClearIm = RmvStr(Text);
ClearIm1 = RmvStr(Text1);
ClearIm2 = RmvStr(Text2);
figure;
subplot(1,2,1);imshow(Text);title('Text.gif')
subplot(1,2,2);imshow(ClearIm);title('Cleared Text')
pause;
figure;
subplot(1,2,1);imshow(Text1);title('Text1.gif')
subplot(1,2,2);imshow(ClearIm1);title('Cleared Text')
pause
figure;
subplot(1,2,1);imshow(Text2);title('Text2.jpg')
subplot(1,2,2);imshow(ClearIm2);title('Cleared Text')
disp('Solution: Use the Sobel operator to detect vertical and horizontal edges, apply threshold. Remove the stripes which are less than threshold value.Assign 0 to magnitudes which are stronger than threshold value.');
%---Finish Solving Problem III---%
pause;
%---Close all figures and clear all variables---%
clear;
close all;

