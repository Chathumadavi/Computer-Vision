%---Chathumadavi Ediriweera, Assignment 3---%
%---Defining RmvStr function---%
function ClearIm = RmvStr(im)
[row,col,ch]=size(im);
if ch>1
    im=rgb2gray(im);
end
Gx=[-1 -2 -1;0 0 0;1 2 1];
Gy=[-1 0 1;-2 0 2;-1 0 1];

filteredImX= conv2(im,Gx);
filteredImY= conv2(im,Gy);
Mag= abs(filteredImX)+abs(filteredImY);

     

Mag = Mag(2:end, 2:end);
cutoff = 4*sum(Mag(:),'double') / numel(Mag);

[r,c]=size(Mag);
ClearIm=zeros([r c]);
for i=1:r
    for j=1:c
        if Mag(i,j)> cutoff
            ClearIm(i,j)=0;
        else
            ClearIm(i,j)=1;
        end
    end
end  
ClearIm = ClearIm(2:end, 2:end);

end