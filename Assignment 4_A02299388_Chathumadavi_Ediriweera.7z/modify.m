%---Chathumadavi Ediriweera, Assignment 4---%

%---Defining modify function---%
function [V1,H1,D1]=modify(V,H,D,t)
%---Modify the wavelet coefficient for LH---%
[k,l]=size(V);
 V1=V;
 for i=1:k
     for j=1:l
         if V(i,j)>=t
            V1(i,j)=V(i,j)-t;
         elseif V(i,j)<=(-t)
            V1(i,j)=V(i,j)+t;
         elseif abs(V(i,j))<t
            V1(i,j)=0;
         end
     end
 end
 
 %---Modify the wavelet coefficient for LH---%
 [k,l]=size(H);
 H1=H;
 for i=1:k
     for j=1:l
         if H(i,j)>=t
            H1(i,j)=H(i,j)-t;
         elseif H(i,j)<=(-t)
            H1(i,j)=H(i,j)+t;
         elseif abs(H(i,j))<t
            H1(i,j)=0;
         end
     end
 end
 
 %---Modify the wavelet coefficient for HH---%
  [k,l]=size(D);
 D1=D;
 for i=1:k
     for j=1:l
         if D(i,j)>=t
            D1(i,j)=D(i,j)-t;
         elseif D(i,j)<=(-t)
            D1(i,j)=D(i,j)+t;
         elseif abs(D(i,j))<t
            D1(i,j)=0;
         end
     end
 end
 
end