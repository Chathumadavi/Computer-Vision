%---Chathumadavi Ediriweera, Assignment 4---%

%---Define function to find locations of largest four frequencies---%

function new_im=find_loc(im,L)
[r,c]=size(im);
l=length(L);

a=zeros([1,8]);
x=1;
for u=1:r
    for v=1:c
        for i=1:l
            if abs(im(u,v))==L(i)
                
                a(x)=im(u,v);
                x=x+1;
            end
        end
    end
end
new_im=im;
for u=1:r
        for v=1:c
             for i=1:(l*2)
                 if im(u,v)==a(i)       
                    temp= [im(u-1,v-1),im(u-1,v),im(u-1,v+1),im(u,v-1),im(u,v+1),im(u+1,v-1),im(u+1,v),im(u+1,v+1)];
                    new_im(u,v)= mean(temp);
%                   
                 end
                
            end
        end
    
end

end