%---Chathumadavi Ediriweera, Assignment 4---%


%---Load the image---%
Im=imread('Sample.jpg');
FIm=fft2(Im);
CenterFIm=fftshift(FIm);

[x,y]=size(Im);
cu=floor(x/2+1);
cv=floor(y/2+1);

%---Design a gaussian low-pass filter---%
Hg=zeros([x,y]);
S1=2*(75^2);
S2=2*(25^2);
for u=1:x
    for v=1:y
        Hg(u,v)= exp((-(u-cu)^2/S1)+(-(v-cv)^2/S2));
    end
end
FilCIm=CenterFIm.*Hg;
InFilIm= ifftshift(FilCIm);
FilIm= ifft2(InFilIm);
ConvIm=uint8(real(FilIm));
figure;
subplot(1,3,1)
imshow(Im)
title('Original Image')
subplot(1,3,2)
imshow(Hg)
title('Gaussian Low Pass Filter')
subplot(1,3,3)
imshow(ConvIm)
title('Filtered Image')
%---Finish Solving Problem I.1---%
pause;

%---Design a butterworth high-pass filter---%

D0=40;

Hb=zeros([x,y]);

n=2;
for u=1:x
    for v=1:y
        Hb(u,v)= 1-(1/(1+(((sqrt((u-cu)^2+(v-cv)^2))/D0)^(2*n))));
       
    end
end
% FIm=fft2(Im);
% CenterFIm=fftshift(FIm);
FilCIm2=CenterFIm.*Hb;
InFilIm2= ifftshift(FilCIm2);
FilIm2= ifft2(InFilIm2);
ConvIm2=uint8(real(FilIm2));
figure;
subplot(1,3,1)
imshow(Im)
title('Original Image')
subplot(1,3,2)
imshow(Hb)
title('Butterworth High Pass Filter')
subplot(1,3,3)
imshow(ConvIm2)
title('Filtered Image')
%---Finish Solving Problem I.2---%
pause;

%---Problem II: Noise Modeling and Basic Restoration Techniques---%
City=imread('City.jpg');
[r,c]=size(City);
k = 0.0025;
x=5/3;
Hn=zeros([r,c]);
for u=1:r
    for v=1:c
        D=sqrt((u-cu)^2+(v-cv)^2);
        a=D^x;
        b=k*a;
        Hn(u,v)=exp(-b);
    end
end
FCity=fft2(City);
CenterFCity=fftshift(FCity);
FilCity=CenterFCity.*Hn;
InFilCity= ifftshift(FilCity);
FilImC= ifft2(InFilCity);
ConvImC=uint8(real(FilImC));
imwrite (ConvImC, 'BlurCity.bmp');
figure;
subplot(1,2,1)
imshow(Hn)
title('Noise Generating Filter')
subplot(1,2,2)
imshow(ConvImC)
title('Turbulent Image')
%---Finish Solving Problem II.1---%
pause;

Blur=imread('BlurCity.bmp');
FBlur=fft2(Blur);
CenterFBlur=fftshift(FBlur);
Hw=zeros([r,c]);
g=0.00005;
for u=1:r
    for v=1:c
%         a= abs(Hn(u,v))^2;
        Hw(u,v)=(1/Hn(u,v)*((abs(Hn(u,v))^2)/((abs(Hn(u,v))^2)+g)));
    end
end
FilBlur=CenterFBlur.*Hw;
InFilBlur= ifftshift(FilBlur);
FilImB= ifft2(InFilBlur);
ConvImB=uint8(real(FilImB));

figure;
imshow(ConvImB)
title('Restored Image')
%---Finish Solving Problem II.2---%
pause;

%---Problem III: Exercise on Certain Operations in the Frequency Domain---%

%---Loading Capitol.jpg image and Transforming to frequency domain---%
Capitol=imread('Capitol.jpg');
FCap=fftshift(fft2(Capitol));


%---Extracting magnitude---%
mag_Capitol = abs(FCap);                               % Magnitude for Capitol
%FCap(m<1e-6) = 0;
mag_Sample = abs(CenterFIm);                             %Magintude for Sample

minc=min(min(mag_Capitol));
maxc=max(max(mag_Capitol));
mins=min(min(mag_Sample));
mins=max(max(mag_Sample));

%---Log transformation and scaling of Magnitude---%
[mc, ~]= Scaling(log(mag_Capitol),[0,255]);
[ms, ~]= Scaling(log(mag_Sample),[0,255]);
%---Extracting Phase---%
pc=angle(FCap);                                     % Phase for Capitol
ps=angle(CenterFIm);                                      % Phase for Sample
phase_Capitol = uint8(Scaling(pc,[0,255]));                     
phase_Sample = uint8(Scaling(ps,[0,255]));                     


figure

mc=uint8(mc);
subplot(2,2,1)
imshow(mc)
title('Magnitude of Capitol')

ms=uint8(ms);
subplot(2,2,2)
imshow(phase_Capitol)
title('Phase of Capitol')

subplot(2,2,3)
imshow(ms)
title('Magnitude of Sample')


subplot(2,2,4)
imshow(phase_Sample)
title('Phase of Sample')
%---Finish Solving Problem III.1---%
pause;

%---Reconstructing images by combining magnitude and phase of different images---%
[r,c]= size(Capitol);
for u=1:r
    for v=1:c
        e= exp(1i*ps(u,v));
        F_Capitol(u,v)=abs(FCap(u,v)).*e;
        
        e1= exp(1i*pc(u,v));
        F_Sample(u,v)=abs(CenterFIm(u,v)).*e1;

    end
end

%---Transformng into spatial domain---%
InvF_Capitol=real(uint8(ifft2 (ifftshift(F_Capitol))));
InvF_Sample=real(uint8(ifft2(ifftshift(F_Sample))));

%---Displaying Reconstructed Images---%
figure
subplot(1,2,1)
imshow(InvF_Capitol)
title('Reconstructed Capitol')

subplot(1,2,2)
imshow(InvF_Sample)
title('Reconstructed Sample')
%---Finish Solving Problem III.2---%
pause;

%---Problem IV: Remove Additive Cosine Noise---%

%---Transforming into frequency domain& Computing Centered DFT---%
noisy_boy=imread('boy_noisy.gif');
FNB=fft2(noisy_boy);
CenterFNB=fftshift(FNB);

%---Calling find_freq function to select largest frequencies---%
L=find_freq(CenterFNB); 

%---Calling find_loc function to locate largest frequencies---%
newIm=find_loc(CenterFNB,L);

%---Transformng into spatial domain---%
InvnewIm=real(uint8(ifft2(ifftshift(newIm))));

%---Displaying Original and Reconstructed Images---%
figure
subplot(1,2,1)
imshow(noisy_boy)
title('Original Image')

subplot(1,2,2)
imshow(InvnewIm)
title('Reconstructed Sample')
%---Finish Solving Problem IV---%
pause;

%---Problem V: Preliminary Wavelet Transform---%
%---Load the image---%
Lena= imread('Lena.jpg');
X= size(Lena);
%---Matlab built-in function for maximum-level decomposition---%
n=wmaxlev(X,'db2');

%---Change active extension mode into periodic---%
dwtmode("per") ;
%---maximum-level �db2� wavelet decomposition---%
[C,S] = wavedec2(Lena,n,'db2');

%---inverse wavelet transform to restore the image----%
RecLena= uint8(waverec2(C,S,'db2'));

if isequal(Lena,RecLena)
    disp('Success:The Original image and Restored image are equal');
else
    disp('Error:The Original image and Restored image are not equal');
end
%---Finish Solving Problem V.1---%
pause;

%---Set the four values of each 2�2 non-overlapping block in the approximation subband as its average---%
x = floor(n/2);
img = im2double(Lena);
[CA1,CH1,CV1,CD1]=dwt2(img,'db2');
[CA2,CH2,CV2,CD2]=dwt2(CA1,'db2');
[CA3,CH3,CV3,CD3]=dwt2(CA2,'db2');

[r,c]=size(CA3);
A3=CA3;
 for i=1:2:r
    for j=1:2:c
        avg_CA3=sum(sum(CA3(i:i+1,j:j+1)))/4;
        A3(i:i+1,j:j+1)=avg_CA3;
    end
 end

RecCA2=idwt2(A3,CH3,CV3,CD3,'db2');
RecCA1=idwt2(RecCA2,CH2,CV2,CD2,'db2');
RecCA1=RecCA1(2:258,2:258);
RecIm= idwt2(RecCA1,CH1,CV1,CD1,'db2');
figure
imshow(RecIm)
title('CA3 Averaged Image')
pause;

%---Set the first level vertical detail coefficients (e.g., LH1) as 0�s---%
[k,l]=size(CV1);
 V1=CV1;
for i=1:k
     for j=1:l
         V1(i,j)=0;
     end
 end
 
 RecCA2=idwt2(CA3,CH3,CV3,CD3,'db2');
 RecCA1=idwt2(RecCA2,CH2,CV2,CD2,'db2');
 RecCA1=RecCA1(2:258,2:258);
 RecIm2= idwt2(RecCA1,CH1,V1,CD1,'db2');
 figure
 imshow(RecIm2)
 title('CV1 modified image')
 pause;
 
 %---Set the second level horizontal detail coefficients (e.g., HL2) as 0�s---%
 [m,n]=size(CH2);
H2= CH2;
for i=1:m
     for j=1:n
         H2(i,j)=0;
     end
end
RecCA2=idwt2(CA3,CH3,CV3,CD3,'db2');
RecCA1=idwt2(RecCA2,H2,CV2,CD2,'db2');
RecCA1=RecCA1(2:258,2:258);
RecIm3= idwt2(RecCA1,CH1,CV1,CD1,'db2');
figure
imshow(RecIm3)
title('CH2 modified image')
%---Finish Solving Problem V.2---%
pause;

%---Problem VI: A Simple Solution to Remove Gaussian White Noise---%
%---call imnoise function---%
J = imnoise(Lena,'gaussian',0,0.01);

%---Apply a 3-level �db2� wavelet decomposition---%
[CA1,CH1,CV1,CD1]=dwt2(Lena,'db2');
[CA2,CH2,CV2,CD2]=dwt2(CA1,'db2');
[CA3,CH3,CV3,CD3]=dwt2(CA2,'db2');


%---Estimate the noise variance at the 1st-level wavelet subband---%
[noise_variance] = variance(CH1,CV1,CD1); %---Calling noise variance function---%

%---Compute the adaptive threshold t---%
[t1]=threshold(noise_variance,CV1);

%---Modify the 1st-level wavelet coefficients---%
[V1,H1,D1]=modify(CV1,CH1,CD1,t1);

 %---2nd-level wavelet subband---%
 
 %---Estimate the noise variance at the 2nd-level wavelet subband---%
 [noise_variance2] = variance(CH2,CV2,CD2);
 

%---Compute the adaptive threshold t---%
[t2]=threshold(noise_variance2,CV2);

%---Modify the 2nd level wavelet coefficients---%
[V2,H2,D2]= modify(CV2,CH2,CD2,t2);

 %---3rd-level wavelet subband---%
 
 %---Estimate the noise variance at the 3rd-level wavelet subband---%
 [noise_variance3] = variance(CH3,CV3,CD3);


%---Compute the adaptive threshold t---%

[t3]=threshold(noise_variance3,CV3);

%---Modify the 3rd level wavelet coefficients---%
[V3,H3,D3]= modify(CV3,CH3,CD3,t3);

%---inverse wavelet transform---% 
RecCA2=idwt2(CA3,H3,V3,D3,'db2');
RecCA1=idwt2(RecCA2,H2,V2,D2,'db2');
RecCA1=RecCA1(2:258,2:258);
Denoise= uint8(idwt2(RecCA1,H1,V1,D1,'db2'));
figure
subplot(1,2,1)
J=im2double(J);
imshow(J)
title('Noisy image')
subplot(1,2,2)
imshow(Denoise)
title('Denoised image')
%---Finish Solving Problem VI---%
pause;

close all;
clear;
