%---Chathumadavi Ediriweera, Assignment 4---%

%---Defining Scaling function---%
function[scaledIm, transFunc] = Scaling(Im, range)
Im = double(Im);
sorted_vec = sort(Im(:));
l = length(sorted_vec);

min_in = sorted_vec(1);
max_in = sorted_vec(l);
min_out = range(1);
max_out = range(2);

m = (max_out-min_out)/(max_in-min_in);

scaledIm = ((m*(Im-min_in))+min_out);

transFunc = (sort(unique(scaledIm(:))));
transFunc = uint8(transFunc);
end