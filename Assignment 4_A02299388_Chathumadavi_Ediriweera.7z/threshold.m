%---Chathumadavi Ediriweera, Assignment 4---%

%---Defining threshold function---%

function [t]=threshold(var,V)
%---number of elements in the wavelet subband---%
[r,c]=size(V);
M= 3*r*c;

%---Compute the adaptive threshold t of the 1st-level wavelet subband---%
sigma=sqrt(var);
t= sigma*sqrt(2*log(M));
end