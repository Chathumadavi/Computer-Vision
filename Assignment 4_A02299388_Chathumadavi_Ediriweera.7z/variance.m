%---Chathumadavi Ediriweera, Assignment 4---%

%---Defining variance function---%

function [noise_variance] = variance(H,V,D)
W=horzcat(H(:),V(:),D(:));
W=W(:);
%---Horizontal noise variance---%
noise_varianceCH1= median(abs(H))/0.6745;

%---Vertical noise variance---%
noise_varianceCV1= median(abs(V))/0.6745;

%---Diagonal noise variance---%
noise_varianceCD1= median(abs(D))/0.6745;

%---Noise variance---%
noise_variance= median(abs(W))/0.6745;
end