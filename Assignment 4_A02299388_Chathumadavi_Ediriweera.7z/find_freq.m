%---Chathumadavi Ediriweera, Assignment 4---%

%---Define function to find largest four frequencies except the center location---%

function L=find_freq(im)
%---Extracting Magnitude---%
mag= abs(im);
%---Extracting unique value array---%
mag_array=unique(mag(:));
%---Sorting in descending order---%
sorted_mag=(sort(mag_array,'descend'));

L=zeros([4,1]);
%---Selecting the largest frequencies except the center location frequencies---%
for i=2:5
L(i-1)=sorted_mag(i,1);

end
