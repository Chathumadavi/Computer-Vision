%---Chathumadavi Ediriweera, Assignment 5---%

%---Problem I---%
%---Load the image---%
City = imread('City.jpg');

%Convert the image to binary image---%
f= imbinarize(City);

%---Creating structuring element---%
b= strel('square',3);

%---Dilation---%
df= imdilate(f,b);

%---Erosion---%
ef= imerode(f,b);

%---morphological gradient operation---%
g= df - ef;

%---Display Resultant Image---%
figure
imshow(g)
title('Resultant Image')
%---Finish Solving Problem I.1---%
pause;

%Problem I.2%
%---Load image---%
SS= imread('SmallSquares.tif');

%---Complement Image%
InvS = imcomplement(SS);
 
%--SE for foreground matching---%
B1 = strel([0 1 1;0 1 1;0 0 0]);
%--SE for background matching---%
B2 = strel([1 0 0;1 0 0;1 1 1]);

%---Foreground matching---%
FIm= imerode(SS,B1);

%---Background Matching---%
BIm= imerode(InvS,B2);

%Result= FIm-BIm;
Result= (FIm)&(BIm); 

figure
imshow(Result)
title('Resultant image')

%---Size of Image---%
[r,c]=size(SS);
count = 0;
for i=1:r-2
    for j=1:c-2
        if SS(i,j)==0 & SS(i,j+1)==0 & SS(i,j+2)==0 & SS(i+1,j+2)==0 & SS(i+2,j+2)==0 & SS(i+1,j)==1 & SS(i+1,j+1)==1 & SS(i+2,j+1)
            count=count+1;
        end
    end
end
disp('the number of foreground pixels:')
disp(count);
%---Finish Solving Problem I.2---%
pause;

%Problem I.3%
%---Load image---%
WB= imread('Wirebond.tif');

%---converting the image into its complement---%
InvWB = imcomplement(WB);

%---Creating structuring element---%
b= strel('square',14);

%---Dilation---%
df= imdilate(InvWB,b);

%---Creating structuring element---%
b2= strel('square',10);

%---Dilation---%
df2= imdilate(InvWB,b2);

%---Creating structuring element---%
b3= strel('square',50);

%---Dilation---%
df3= imdilate(InvWB,b3);

figure
subplot(1,3,1)
imshow(imcomplement(df))
title('Desired Image 1')
subplot(1,3,2)
imshow(imcomplement(df2))
title('Desired Image 2')
subplot(1,3,3)
imshow(imcomplement(df3))
title('Desired Image 3')
%---Finish Solving Problem I.3---%
pause;

%---Problem I.4---%

%---Load image---%
Shape= imread('Shapes.tif');

%---converting the image into its complement---%
InvS = imcomplement(Shape);
 
%---Creating structuring element---%
s= strel('square',20);
 
%---close operation---%
Jclose = imclose(InvS,s);

%---open operation---%
Jopen = imopen(InvS,s);


%---close operation---%
J = imclose(Jopen,s);


figure
subplot(1,3,1)
imshow(imcomplement(Jclose))
title('Desired Image 1')
subplot(1,3,2)
imshow(imcomplement(Jopen))
title('Desired Image 2')
subplot(1,3,3)
imshow(imcomplement(J))
title('Desired Image 3')
%---Finish Solving Problem I.4---%
pause;

%---Problem I.5---%
%---Load image---%
D= imread('Dowels.tif');

%---Convert in to binary image---%
DB= imbinarize(D);

%---SE element---%
SE = strel('disk',5);

%---open opertion followed by close operation---%
%Dopen= imopen(DB,SE);
Dopen_close = imclose((imopen(DB,SE)),SE);

%---close opertion followed by open operation---%
%Dclose= imclose(DB,SE);
Dclose_open = imopen((imclose(DB,SE)),SE);


figure
subplot(1,2,1)
imshow(Dopen_close)
title('open-close operation')
subplot(1,2,2)
imshow(Dclose_open)
title('close-open operation')
pause;

for i=2:5
    
    %---SE element---%
    SE = strel('disk',i);
    
    %---open opertion followed by close operation---%
    Dopen_close = imclose((imopen(DB,SE)),SE);
    DB = Dopen_close;
end
for i=2:5
    %---close opertion followed by open operation---%
    Dclose_open = imopen((imclose(DB,SE)),SE);
    DB= Dclose_open;
end
    
    figure
    subplot(1,2,1)
    imshow(Dopen_close)
    title('Series of open-close operation')
    subplot(1,2,2)
    imshow(Dclose_open)
    title('Series of close-open operation')

%---Finish Solving Problem I.5---%
pause;

%---Problem II: Applications of Morphological Operations---%
%---Load image---%
Ball= imread('Ball.tif');

%---SE element---%
SE = strel('square',3);
%Problem 2.1%
%---FindComponentLabels Calling function---%
[labelIm, num] = FindComponentLabels(Ball, SE);

disp('Number of connected particles');
disp(num);

% lIm = labelIm*(255/num);
% lIm= uint8(lIm);
figure
imshow(labelIm)
title('Connected Components')
%---Finish Solving Problem II.1---%
pause;

%---Calling matlab built-in function to find connected components---%
Con_Comp=bwconncomp(Ball);
label=labelmatrix(Con_Comp);
num=Con_Comp.NumObjects;
scaled_label = label*(255/num);
Result_CC= uint8(scaled_label);
figure
imshow(Result_CC)
title('Matlab Connected Component')
disp('Matlab number of connected particles');
disp(num);

%---Finish Solving Problem II.2---%
pause;

A= labelIm;
[r,c]=size(labelIm);
for i=1
    for j=1:c
        if labelIm(i,j)>0
            label= labelIm(i,j);
            position = find(labelIm==label);
            A(position)=0;
        end
    end
end

for i=1:r
    for j=1
        if labelIm(i,j)>0
            label= labelIm(i,j);
            position = find(labelIm==label);
            A(position)=0;
        end
    end
end

for i=r
    for j=1:c
        if labelIm(i,j)>0
            label= labelIm(i,j);
            position = find(labelIm==label);
            A(position)=0;
        end
    end
end

for i=1:r
    for j=c
        if labelIm(i,j)>0
            label= labelIm(i,j);
            position = find(labelIm==label);
            A(position)=0;
        end
    end
end
num=sum(unique(A(:)) ~= 0);
disp('number of connected particles not residing on the border');
disp(num);

figure
subplot(1,2,1)
imshow(Ball)
title('Input Image')
subplot(1,2,2)
imshow(A)
title('Connected Components not residing on the border')
%---Finish Solving Problem II.3---%
pause;


%---Calling built-in matlab function to find connected particles not residing on the border of the image---%
Con_Comp2 = bwconncomp(imclearborder(Ball));
label2=labelmatrix(Con_Comp2);
num2=Con_Comp2.NumObjects;
scaled_label2 = label2*(255/num);
Result_CC2= uint8(scaled_label2);

figure
subplot(1,2,1)
imshow(A)
title('Image A')
subplot(1,2,2)
imshow(Result_CC2)
title('Matlab function to remove Objects touching borders')
disp('Matlab number of connected particles not residing on the border');
disp(num2);
%---Finish Solving Problem II.4---%
pause;

%---non-overlapping connected particles not residing on the border---%

Con_Comp3 = bwconncomp(imclearborder(Ball));
label3=labelmatrix(Con_Comp3);
measurements = regionprops(label3, 'Area');
allAreas = [measurements.Area];  % List of all the blob areas.
round_allAreas= roundn(allAreas,1);
min_area =min(round_allAreas);
pos=find (round_allAreas==min_area);
[r,c]=size(Ball);
B= zeros([r,c]);
for i=1:r
    for j=1:c
        for k=1:length(pos)
            if label3(i,j)== pos(k)
                 B(i,j)=pos(k); 
            end
        end
    end
end

B = B*(255/length(allAreas));
B= uint8(B);

figure
subplot(1,2,1)
imshow(Ball)
title('Original Image')
subplot(1,2,2)
imshow(B)
title('non-overlapping particles')

disp('Number of non-overlapping particles:');
disp(length(pos));
%---Finish Solving Problem II.5---%
pause;

close 'all';
clear;