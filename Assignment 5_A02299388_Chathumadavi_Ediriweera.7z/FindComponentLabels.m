%---Chathumadavi Ediriweera, Assignment 5---%

%---Defining FindComponentLabels function---%

function [labelIm, num] = FindComponentLabels(im,se)

%Size of the image
[r,c]=size(im);
count = 0;

%Creating matrices with same size as image
labelIm=zeros([r,c]); %labeled image
compIm=zeros([r,c]);  %p point image
dilateIm=zeros([r,c]); %dilated image

for i=1:r
    for j=1:c
            if (im(i,j)==1)&& (labelIm(i,j)==0) 
                compIm(i,j)=1;
                while 1
                dilateIm = (imdilate(compIm,se))&im;
                if dilateIm == compIm
                    break;
                end
                compIm=dilateIm;
                end
               
               position = find(dilateIm==1);
               count= count+1;
               labelIm(position)=count; 
               compIm=zeros([r,c]);
               dilateIm=zeros([r,c]);
             end
      
    end
     
end
num=count;
labelIm = labelIm*(255/num);
labelIm= uint8(labelIm);

end