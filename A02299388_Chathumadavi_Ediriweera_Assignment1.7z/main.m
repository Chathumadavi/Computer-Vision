%---Chathumadavi Ediriweera, Assignment 1---%

%---Load the image peppers.bmp into a variable A---%
A=imread('peppers.bmp');

%---Display loaded image A on figure with the figure title---%
figure;
imshow(A);
title('RGB Original Image')
%---Finish Solving Problem 1---%
pause;

%---Convert image into a grayscale image---%
B=rgb2gray(A);
%---transpose image---%
TB=transpose(B);

%---Horizontal flip---%
HB=B;
[row,col,n]=size(B);
HB(1:row/2,:)=B(row/2+1:end,:);
HB(row/2+1:end,:)=B(1:row/2,:);

%---flip left/right---%
FB= fliplr(B);

%---Display images B, TB, HB, and FB---%
figure;
subplot(2,2,1)
imshow(B)
title('B')

subplot(2,2,2)
imshow(TB)
title('TB')

subplot(2,2,3)
imshow(HB)
title('HB')

subplot(2,2,4)
imshow(FB)
title('FB')
%---Finish Solving Problem 2---%
pause;

%---Calling max,min,mean,median Matlab built-in functions---%
maximum_value=max(B(:));
minimum_value=min(B(:));
mean_value=mean(B(:));
median_value=median(B(:));

%---Calling FindInfo function---%
[maxValue, minValue, meanValue, medianValue] = FindInfo(B);

%---Comparison between Findinfo vs matlab built-in functions---%
if maximum_value== maxValue && minimum_value== minValue && mean_value==meanValue && median_value==medianValue
    disp('Your computation is successful!')
    disp([maximum_value,maxValue])
    disp([minimum_value,minValue])
    disp([mean_value,meanValue])
    disp([median_value,medianValue])
else
    disp('Something went Wrong!')
end
    
%---Finish Solving Problem 3---%
pause;

%---Normalize image---%
C = double(B)/double(maximum_value);
figure; 
imshow(C);
title('Normalized Grayscale Image');
pause;

%---Process image---%
D=C;
D(:,(end/4)+1:end/2)=C(:,(end/4)+1:end/2).^1.25;
D(:,3*(end/4)+1:end)=C(:,3*(end/4)+1:end).^0.75;
figure;
imshow(D);
title('Processed Grayscale Image');
pause;
%---Save image---%
imwrite(D,'Chathumadavi_D.jpg');
%---Finish Solving Problem 4---%
pause;

%---Solution 1 for binary thresholding---%
bw1=C;
z=find(bw1<=0.3);
bw1(z)=0;
o=find(bw1>0.3);
bw1(o)=1;

%---Solution 2 for binary thresholding---%
bw2=C;
bw2(bw2<=0.3)=0;
bw2(bw2>0.3)=1;

%---Matlab built-in function---%
bw3=imbinarize(C,0.3);

%---Comparing bw1 and bw2 with bw3---%
if bw1 == bw3 & bw2 == bw3
    disp('Both of my methods worked')
elseif bw1==bw3 & bw2~=bw3
    disp('My method 1 worked but not my method 2')
elseif bw2==bw3 & bw1~=bw3
    disp('My method 2 worked but not my method 1')
else
    disp('Both of my two methods did not work')
end

%---Display bw1,bw2,bw3---%
figure;
subplot(1,3,1);
imshow(bw1);
title('my first method');

subplot(1,3,2);
imshow(bw1);
title('my second method');

subplot(1,3,3);
imshow(bw1);
title('Matlab method');
%---Finish Solving Problem 5---%
pause;

%---Calling BlurImage function---%
BA = BlurImage(A);
BB = BlurImage(B);

%---Display A,B,BA,BB images---%
figure;
subplot(2,2,1);
imshow(A);
title('A');

subplot(2,2,2);
imshow(B);
title('B');

subplot(2,2,3);
imshow(BA);
title('BA');

subplot(2,2,4);
imshow(BB);
title('BB');
%---Finish Solving Problem 6---%
pause;

%---Close all figures and clear all variables---%
clear;
close all;
%---Finish Solving Problem 7---%



