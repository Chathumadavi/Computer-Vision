%---Chathumadavi Ediriweera, Assignment 1---%

function [blurredIm] = BlurImage(oriIm)
blurredIm = oriIm;
[row, col, channel] = size(oriIm);
for ch = 1:channel
    for r = 1:2:row-1
        for c = 1:2:col-1
            blurredIm(r:r+1,c:c+1,ch) = mean(mean(oriIm(r:r+1,c:c+1,ch)));
        end
    end
end
end