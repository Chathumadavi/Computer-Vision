%---Chathumadavi Ediriweera, Assignment 1---%

function [maxValue, minValue, meanValue, medianValue] = FindInfo(oriIm)
vector= oriIm(:);
vector= sort(vector);

maxValue= vector(end);
minValue= vector(1);
meanValue= sum(vector)/length(vector);

l = length(vector);
 if rem(l,2)==0
    medianValue=(vector(end/2)+ vector(end/2+1))/2;
 else
    medianValue=vector((end+1)/2);
 end

end
